//
//  ViewController.swift
//  TestFramework
//
//  Created by bo on 16/3/23.
//  Copyright © 2016年 huami. All rights reserved.
//

import UIKit
import MyFramework

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


    @IBAction func openStoryboard(sender: AnyObject) {
        MyFramework.openVCFromStoryboard()
    }

    @IBAction func openXib(sender: AnyObject) {
        MyFramework.openVCFromXib()
    }
    
    @IBAction func loadImage(sender: AnyObject) {
        let image = MyFramework.loadImage()
        print(image.size)
    }
    
}


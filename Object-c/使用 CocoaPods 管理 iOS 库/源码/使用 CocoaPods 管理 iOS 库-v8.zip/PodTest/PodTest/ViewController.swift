//
//  ViewController.swift
//  PodTest
//
//  Created by bo on 16/3/21.
//  Copyright © 2016年 huami. All rights reserved.
//

import UIKit
import MyFramework

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func storyboard(sender: AnyObject) {
        MyFramework.openVCFromStoryboard()
    }

    @IBAction func xib(sender: AnyObject) {
        MyFramework.openVCFromXib()
    }
    
    @IBAction func image(sender: AnyObject) {
        print(MyFramework.loadImage().size)
    }
    
}


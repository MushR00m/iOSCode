//
//  NAFReportUtil.h
//  NAntiFraudSDKTest
//
//  Created by yangmengge on 16/8/31.
//  Copyright © 2016年 niwodai. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <NAntiFraudSDK/NAFReportUtils.h>
#import <NAntiFraudSDK/NAFReportDefine.h>

//登录
#define NAF_SDK_LOGIN @"login"
//注册
#define NAF_SDK_REGISTER @"register"
//交易
#define NAF_SDK_TRANSATION @"transaction"
//浏览
#define NAF_SDK_PAGEVIEW @"pageview"
//按钮
#define NAF_SDK_BUTTON @"button"
//点击
#define NAF_SDK_CLICK @"click"
//关闭
#define NAF_SDK_CLOSE @"close"


@interface NAFReportUtil : NSObject
/** 页面标题统计 */
+ (void)trackState:(NSString *)name;
+ (void)trackState:(NSString *)name data:(NSDictionary *)data;
/** 事件统计 */
+ (void)trackAction:(NSString *)name;
+ (void)trackAction:(NSString *)name data:(NSDictionary *)data;

//新加入
+ (void)trackWithName:(NSString *)name;
+ (void)trackWithName:(NSString *)name data:(NSDictionary *)data;

/** 统计交易相关 */
+ (void)trackTransaction:(NSString *)name transactionType:(NSString *)type amount:(NSString *)amount;
+ (void)trackTransaction:(NSString *)name transactionType:(NSString *)type amount:(NSString *)amount data:(NSDictionary *)data;
+ (void)trackTransaction:(NSString *)name data:(NSDictionary *)data;

@end

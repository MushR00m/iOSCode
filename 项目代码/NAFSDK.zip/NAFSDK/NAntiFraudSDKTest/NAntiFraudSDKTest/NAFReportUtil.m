//
//  NAFReportUtil.m
//  NAntiFraudSDKTest
//
//  Created by yangmengge on 16/8/31.
//  Copyright © 2016年 niwodai. All rights reserved.
//

#import "NAFReportUtil.h"

@implementation NAFReportUtil

/** 页面标题统计 */
+ (void)trackState:(NSString *)name
{
    [self trackState:name data:nil];
}

+ (void)trackState:(NSString *)name data:(NSDictionary *)data
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    if (data) {
        [dict setDictionary:data];
    }
    
    [dict setObject:BI_VALUE_T_PAGEVIEW forKey:BI_KEY_T];
    
    [self addDataWithName:name toData:dict];
    
    [NAFReportUtils trackWithName:name data:dict];
}

/** 事件统计 */
+ (void)trackAction:(NSString *)name
{
    [self trackAction:name data:nil];
}

+ (void)trackAction:(NSString *)name data:(NSDictionary *)data
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    if (data) {
        [dict setDictionary:data];
    }
    
    [dict setObject:BI_VALUE_T_BUTTON forKey:BI_KEY_T];
    [dict setObject:NAF_SAFE_STRING(name) forKey:BI_KEY_BUTTONID];
    
    if ([name containsString:@"【"]) {
        name = [name substringWithRange:NSMakeRange(1, [name rangeOfString:@"】"].location-1)];
    }
    
    [self addDataWithName:name toData:dict];
    
    [NAFReportUtils trackWithName:name data:dict];
}

/** 统计交易相关 */
+ (void)trackTransaction:(NSString *)name transactionType:(NSString *)type amount:(NSString *)amount
{
    [self trackTransaction:name transactionType:type amount:amount data:nil];
}

+ (void)trackTransaction:(NSString *)name transactionType:(NSString *)type amount:(NSString *)amount data:(NSDictionary *)data
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    if (data) {
        [dict setDictionary:data];
    }
    
    [dict setObject:NAF_SAFE_STRING(amount) forKey:BI_KEY_AMOUNT];
    [dict setObject:NAF_SAFE_STRING(type) forKey:BI_KEY_TRANSTYPE];
    
    [self trackTransaction:name data:dict];
}

+ (void)trackTransaction:(NSString *)name data:(NSDictionary *)data
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    if (data) {
        [dict setDictionary:data];
    }
    
    // 交易统计的同时增加页面统计
    NSMutableDictionary *pDict = [NSMutableDictionary dictionaryWithDictionary:data];
    [pDict removeObjectForKey:BI_KEY_AMOUNT];
    [pDict removeObjectForKey:BI_KEY_TRANSTYPE];
    [self trackState:name data:pDict];
    //
    
    [dict setObject:BI_VALUE_T_TRANSACTION forKey:BI_KEY_T];
    
    [self addDataWithName:name toData:dict];
    
    [NAFReportUtils trackWithName:name data:dict];
}

+ (void)addDataWithName:(NSString *)name toData:(NSMutableDictionary *)dict
{
    // 当前页URL。产生请求的URL
    [dict setObject:NAF_SAFE_STRING(name) forKey:BI_KEY_CURURL];
    
    // 当前页的上一页URL。上一页URL
    if ([name containsString:@"-"]) {
        [dict setObject:[name substringToIndex:[name rangeOfString:@"-" options:NSBackwardsSearch].location] forKey:BI_KEY_REFER];
        // 当前页面类型。每个请求都要传中文或者id
        [dict setObject:[name substringFromIndex:([name rangeOfString:@"-" options:NSBackwardsSearch].location + 1)] forKey:BI_KEY_PAGETYPE];
    } else {
        // 当前页面类型。每个请求都要传中文或者id
        [dict setObject:@"null" forKey:BI_KEY_REFER];
        [dict setObject:NAF_SAFE_STRING(name) forKey:BI_KEY_PAGETYPE];
    }
    
    [dict setObject:@"uid" forKey:BI_KEY_UID];
    [dict setObject:@"" forKey:BI_KEY_CID]; // 渠道类型
}

//新加入
+ (void)trackWithName:(NSString *)name
{
    [self trackWithName:name data:nil];
}

+ (void)trackWithName:(NSString *)name data:(NSDictionary *)data
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    if (data) {
        [dict setDictionary:data];
    }
    if ([name isEqualToString:NAF_SDK_LOGIN] || [name isEqualToString:NAF_SDK_PAGEVIEW]) {
    }else if([name isEqualToString:NAF_SDK_CLICK]){
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"click_position"];
    }else if([name isEqualToString:NAF_SDK_REGISTER]){
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"channel"];
    }else if([name isEqualToString:NAF_SDK_TRANSATION]){
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"amount"]; //交易金额
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"type"]; //交易种类
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"pid"]; //交易种类
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"cid"]; //交易种类
    }else if([name isEqualToString:NAF_SDK_BUTTON]){
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"buttonid"]; //当前button操作
    }else if([name isEqualToString:NAF_SDK_CLOSE]){
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"close_reason"]; //关闭原因
    }
    [dict setObject:NAF_SAFE_STRING(name) forKey:@"t"]; //关闭原因
    [self addDataWithName:name toData:dict];
    [NAFReportUtils trackWithName:name data:dict];
}



@end

//
//  ViewController.m
//  NAntiFraudSDKTest
//
//  Created by yangmengge on 16/8/30.
//  Copyright © 2016年 niwodai. All rights reserved.
//

#import "ViewController.h"
#import "NAFReportUtil.h"

//登录
#define NAF_SDK_LOGIN @"login"
//注册
#define NAF_SDK_REGISTER @"register"
//交易
#define NAF_SDK_TRANSATION @"transaction"
//浏览
#define NAF_SDK_PAGEVIEW @"pageview"
//按钮
#define NAF_SDK_BUTTON @"button"
//点击
#define NAF_SDK_CLICK @"click"
//关闭
#define NAF_SDK_CLOSE @"close"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *loginBtn = [[UIButton alloc]initWithFrame:CGRectMake(50, 100, 50, 50)];
    loginBtn.backgroundColor = [UIColor blueColor];
    loginBtn.tag = 201;
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    
    UIButton *registerBtn = [[UIButton alloc]initWithFrame:CGRectMake(110, 100, 50, 50)];
    registerBtn.backgroundColor = [UIColor blueColor];
    registerBtn.tag = 202;
    [registerBtn setTitle:@"注册" forState:UIControlStateNormal];
    
    UIButton *transaction = [[UIButton alloc]initWithFrame:CGRectMake(170, 100, 50, 50)];
    transaction.backgroundColor = [UIColor blueColor];
    transaction.tag = 203;
    [transaction setTitle:@"交易" forState:UIControlStateNormal];
    
    UIButton *pageview = [[UIButton alloc]initWithFrame:CGRectMake(230, 100, 50, 50)];
    pageview.backgroundColor = [UIColor blueColor];
    pageview.tag = 204;
    [pageview setTitle:@"浏览" forState:UIControlStateNormal];
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(50, 160, 50, 50)];
    button.backgroundColor = [UIColor blueColor];
    button.tag = 205;
    [button setTitle:@"按钮" forState:UIControlStateNormal];
    
    UIButton *clickBtn = [[UIButton alloc]initWithFrame:CGRectMake(110, 160, 50, 50)];
    clickBtn.backgroundColor = [UIColor blueColor];
    clickBtn.tag = 206;
    [clickBtn setTitle:@"点击" forState:UIControlStateNormal];
    
    UIButton *closeBtn = [[UIButton alloc]initWithFrame:CGRectMake(170, 160, 50, 50)];
    closeBtn.backgroundColor = [UIColor blueColor];
    closeBtn.tag = 207;
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    
    [loginBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [transaction addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [pageview addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [clickBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [closeBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:loginBtn];
    [self.view addSubview:registerBtn];
    [self.view addSubview:transaction];
    [self.view addSubview:pageview];
    [self.view addSubview:button];
    [self.view addSubview:clickBtn];
    [self.view addSubview:closeBtn];

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)buttonAction:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    NSInteger tag = btn.tag;
    switch (tag) {
        case 201:
            [NAFReportUtil trackWithName:NAF_SDK_LOGIN];
            break;
        case 202:
            [NAFReportUtil trackWithName:NAF_SDK_REGISTER];
            break;
        case 203:
            [NAFReportUtil trackWithName:NAF_SDK_TRANSATION];
            break;
        case 204:
            [NAFReportUtil trackWithName:NAF_SDK_PAGEVIEW];
            break;
        case 205:
            [NAFReportUtil trackWithName:NAF_SDK_BUTTON];
            break;
        case 206:
            [NAFReportUtil trackWithName:NAF_SDK_CLICK];
            break;
        case 207:
            [NAFReportUtil trackWithName:NAF_SDK_CLOSE];
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

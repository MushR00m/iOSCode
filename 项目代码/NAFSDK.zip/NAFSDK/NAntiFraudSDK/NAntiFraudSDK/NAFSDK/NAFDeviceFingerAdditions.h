//
//  JY_DeviceFingerAdditions.h
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/4.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (NAF_Additions)

- (id)jy_safeObjectAtIndex:(NSUInteger)index;
- (NSArray *)jy_uniqueArray;

@end


@interface NSMutableArray (NAF_Additions)

- (void)jy_safeAddObject:(id)object;
- (void)jy_safeAddNilObject;
- (void)jy_safeInsertObject:(id)anObject atIndex:(NSUInteger)index;

@end

@interface NSMutableDictionary (NAF_Additions)

- (void)jy_safeSetObject:(id)anObject forKey:(id<NSCopying>)aKey;
- (void)jy_safeSetValue:(id)value forKey:(NSString *)key;

@end



@interface NSDictionary (NAF_Additions)

- (NSString *)jy_stringForKey:(NSString *)key;
- (NSInteger)jy_integerForKey:(NSString *)key;

@end

@interface NSString (NAF_Additions)

- (NSString *)obfuscate:(NSString *)string withKey:(NSString *)key;
- (NSString*) sha1;

@end

//
//  NAFGlobal.m
//  NAntiFraudSDK
//
//  Created by yangmengge on 16/8/31.
//  Copyright © 2016年 niwodai. All rights reserved.
//

#import "NAFGlobal.h"

@implementation NAFGlobal

static NAFGlobal *_instance;

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[NAFGlobal alloc] init];
    });
    return _instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.appkey = @"";
    }
    return self;
}

@end

//
//  JYDeviceStorage.m
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import "NAFDeviceStorage.h"
#import "NAFReportDefine.h"

static NSString * const NWD_SDK_KEY_IN_KEYCHAIN_SESSIONID = @"com.niwodai.sdk.antifraud.sessionId";
static NSString * const NWD_SDK_KEY_IN_KEYCHAIN_DEVICEID = @"com.niwodai.sdk.antifraud.deviceId";
static NSString * const NWD_SDK_KEY_IN_KEYCHAIN_CFUUID = @"com.niwodai.sdk.antifraud.cfuuid";
static NSString * const NWD_SDK_KEY_IN_KEYCHAIN_APPKEY = @"com.niwodai.sdk.antifraud.appkey";


@implementation NAFDeviceStorage

+ (instancetype)sharedInstance
{
    static NAFDeviceStorage *_instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[NAFDeviceStorage alloc] init];
    });
    return _instance;
}

- (NSMutableDictionary *)getKeychainQuery:(NSString *)service
{
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:
            (__bridge_transfer id)kSecClassGenericPassword,(__bridge_transfer id)kSecClass,
            service, (__bridge_transfer id)kSecAttrService,
            service, (__bridge_transfer id)kSecAttrAccount,
            (__bridge_transfer id)kSecAttrAccessibleAfterFirstUnlock,(__bridge_transfer id)kSecAttrAccessible,
            nil];
}
- (void)save:(NSString *)service data:(id)data
{
    //Get search dictionary
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Delete old item before add new item
    SecItemDelete((__bridge_retained CFDictionaryRef)keychainQuery);
    //Add new object to search dictionary(Attention:the data format)
    [keychainQuery setObject:[NSKeyedArchiver archivedDataWithRootObject:data] forKey:(__bridge_transfer id)kSecValueData];
    //Add item to keychain with the search dictionary
    SecItemAdd((__bridge_retained CFDictionaryRef)keychainQuery, NULL);
}

- (id)load:(NSString *)service
{
    id ret = nil;
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Configure the search setting
    [keychainQuery setObject:(id)kCFBooleanTrue forKey:(__bridge_transfer id)kSecReturnData];
    [keychainQuery setObject:(__bridge_transfer id)kSecMatchLimitOne forKey:(__bridge_transfer id)kSecMatchLimit];
    CFDataRef keyData = NULL;
    if (SecItemCopyMatching((__bridge_retained CFDictionaryRef)keychainQuery, (CFTypeRef *)&keyData) == noErr) {
        @try {
            ret = [NSKeyedUnarchiver unarchiveObjectWithData:(__bridge_transfer NSData *)keyData];
        } @catch (NSException *e) {
            NSLog(@"Unarchive of %@ failed: %@", service, e);
        } @finally {
        }
    }
    return ret;
}

- (void)delete:(NSString *)service
{
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    SecItemDelete((__bridge_retained CFDictionaryRef)keychainQuery);
}

- (BOOL)saveDeviceId:(NSString *)deviceId
{
    if (NAF_CHECK_VALID_STRING(deviceId)) {
        NSMutableDictionary *deviceDict = [[NSMutableDictionary alloc] init];
        [deviceDict setObject:deviceId forKey:NWD_SDK_KEY_IN_KEYCHAIN_DEVICEID];
        [self save:NWD_SDK_KEY_IN_KEYCHAIN_DEVICEID data:deviceDict];
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)saveSessionId:(NSString *)sessionId
{
    if (NAF_CHECK_VALID_STRING(sessionId)) {
        NSMutableDictionary *deviceDict = [[NSMutableDictionary alloc] init];
        [deviceDict setObject:sessionId forKey:NWD_SDK_KEY_IN_KEYCHAIN_SESSIONID];
        [self save:NWD_SDK_KEY_IN_KEYCHAIN_SESSIONID data:deviceDict];
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)saveCFUUID:(NSString *)cfuuid
{
    if (NAF_CHECK_VALID_STRING(cfuuid)) {
        NSMutableDictionary *deviceDict = [[NSMutableDictionary alloc] init];
        [deviceDict setObject:cfuuid forKey:NWD_SDK_KEY_IN_KEYCHAIN_CFUUID];
        [self save:NWD_SDK_KEY_IN_KEYCHAIN_CFUUID data:deviceDict];
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)saveAppkey:(NSString *)appkey
{
    if (NAF_CHECK_VALID_STRING(appkey)) {
        NSMutableDictionary *deviceDict = [[NSMutableDictionary alloc] init];
        [deviceDict setObject:appkey forKey:NWD_SDK_KEY_IN_KEYCHAIN_APPKEY];
        [self save:NWD_SDK_KEY_IN_KEYCHAIN_APPKEY data:deviceDict];
        return YES;
    } else {
        return NO;
    }
}

- (NSString *)getDeviceId
{
    NSMutableDictionary *dict = (NSMutableDictionary *)[self load:NWD_SDK_KEY_IN_KEYCHAIN_DEVICEID];
    NSString *deviceId = [dict objectForKey:NWD_SDK_KEY_IN_KEYCHAIN_DEVICEID];
    if ((deviceId && [deviceId isKindOfClass:[NSString class]] && [deviceId length])) {
        return deviceId;
    }
    return @"";
}

- (NSString *)getSessionId
{
    NSMutableDictionary *dict = (NSMutableDictionary *)[self load:NWD_SDK_KEY_IN_KEYCHAIN_SESSIONID];
    NSString *sessionId = [dict objectForKey:NWD_SDK_KEY_IN_KEYCHAIN_SESSIONID];
    if ((sessionId && [sessionId isKindOfClass:[NSString class]] && [sessionId length])) {
        return sessionId;
    }
    return GET_EXCEPTION;
}

- (NSString *)getCFUUID
{
    NSMutableDictionary *dict = (NSMutableDictionary *)[self load:NWD_SDK_KEY_IN_KEYCHAIN_CFUUID];
    NSString *cfuuid = [dict objectForKey:NWD_SDK_KEY_IN_KEYCHAIN_CFUUID];
    if ((cfuuid && [cfuuid isKindOfClass:[NSString class]] && [cfuuid length])) {
        return cfuuid;
    }
    return GET_EXCEPTION;
}

- (NSString *)getAppkey
{
    NSMutableDictionary *dict = (NSMutableDictionary *)[self load:NWD_SDK_KEY_IN_KEYCHAIN_APPKEY];
    NSString *appkey = [dict objectForKey:NWD_SDK_KEY_IN_KEYCHAIN_APPKEY];
    if ((appkey && [appkey isKindOfClass:[NSString class]] && [appkey length])) {
        return appkey;
    }
    return GET_EXCEPTION;
}

- (void)clearDeviceId
{
    [self delete:NWD_SDK_KEY_IN_KEYCHAIN_DEVICEID];
}

- (void)clearSessionId
{
    [self delete:NWD_SDK_KEY_IN_KEYCHAIN_SESSIONID];
}

- (void)clearCFUUID
{
    [self delete:NWD_SDK_KEY_IN_KEYCHAIN_CFUUID];
}

- (void)clearAPPKEY
{
    [self delete:NWD_SDK_KEY_IN_KEYCHAIN_APPKEY];
}

@end

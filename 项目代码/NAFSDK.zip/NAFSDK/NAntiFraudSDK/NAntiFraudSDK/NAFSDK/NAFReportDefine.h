//
//  BIReportDefine.h
//  NWDBase
//
//  Created by Tove on 16/3/30.
//  Copyright © 2016年 qmwang. All rights reserved.
//

#ifndef BIReportDefine_h
#define BIReportDefine_h

#define DFLog(format, ...)             NSLog(format, ##__VA_ARGS__)

#define GET_EXCEPTION @"NA"
//
// 非法数据检查宏
//
#define NAF_SAFE_STRING(str)  (str.length ? str : @"null")
#define NAF_CHECK_VALID_STRING(__aString)               (__aString && [__aString isKindOfClass:[NSString class]] && [__aString length])
#define NAF_CHECK_VALID_DATA(__aData)                   (__aData && [__aData isKindOfClass:[NSData class]] && [__aData length])
#define NAF_CHECK_VALID_NUMBER(__aNumber)               (__aNumber && [__aNumber isKindOfClass:[NSNumber class]])
#define NAF_CHECK_VALID_ARRAY(__aArray)                 (__aArray && [__aArray isKindOfClass:[NSArray class]] && [__aArray count])
#define NAF_CHECK_VALID_DICTIONARY(__aDictionary)       (__aDictionary && [__aDictionary isKindOfClass:[NSDictionary class]] && [__aDictionary count])
#define AF_CHECK_VALID_SET(__aSet)                     (__aSet && [__aSet isKindOfClass:[NSSet class]] && [__aSet count])

#define AF_KEY_DEVICE          @"device"  // 手机型号
#define AF_KEY_OS               @"os" // 操作系统。移动端必须加在URL中
#define AF_KEY_OSVER         @"osver" // 操作系统版本。移动端必须加在URL中
#define AF_KEY_IDFA         @"idfa" // 广告追踪idfa
#define AF_KEY_PHONENO         @"phoneno" //手机号码


#define BI_KEY_UUID            @"uuid"  // 客户唯一标识符---idfa
#define BI_KEY_T                  @"t" // 请求类型。请求类型,"pageview：统计产生请求的跳转。transaction：统计交易类请求，必须包含交易类型：交易类型，充值、投资等。" uuid MD5
#define BI_KEY_TRANSTYPE  @"transtype" // 交易类型。若t为pageview可为空。
#define BI_KEY_UID              @"uid" // 用户id。未登录则传"null"，uid加密
#define BI_KEY_CURURL        @"cururl" // 当前页URL。产生请求的URL
#define BI_KEY_REFER          @"refer" // 当前页的上一页URL。上一页URL
#define BI_KEY_OS               @"os" // 操作系统。移动端必须加在URL中
#define BI_KEY_OSVER         @"osver" // 操作系统版本。移动端必须加在URL中
#define BI_KEY_TIME            @"time" // 请求时间戳。请求时间戳以客户端发送请求为准，格式为unixtime
#define BI_KEY_AV               @"av" // app版本号。格式：4.6.1
#define BI_KEY_DEVICE        @"device" // 手机型号。iPhone6s
#define BI_KEY_CID              @"cid" // 渠道类型。若为空则为:na|na|na|na|na|na
#define BI_KEY_SR               @"sr" // 屏幕分辨率。格式：1920_1080
#define BI_KEY_AMOUNT      @"amount" // 金额。"当t=pageview是此参数可不填，t=transaction不为空"
#define BI_KEY_SRC             @"src" // 来源。pc,ios,android,wap
#define BI_KEY_OPERATOR   @"operator" // 运营商
#define BI_KEY_NETTYPE     @"nettype" // 网络类型
#define BI_KEY_PAGETYPE   @"pagetype" // 当前页面类型。每个请求都要传中文或者id
#define BI_KEY_BUTTONID   @"buttonid" // 事件统计名称
#define BI_KEY_RID              @"rid" // idfa 加密
#define BI_KEY_MA              @"ma" // mac地址 加密
#define BI_KEY_APPID         @"appid" // app应用id

#define BI_VALUE_T_PAGEVIEW  @"pageview" // 统计产生请求的跳转（页面统计）
#define BI_VALUE_T_BUTTON  @"button" // 事件统计
#define BI_VALUE_T_TRANSACTION  @"transaction" // 统计交易类请求，必须包含交易类型：交易类型，充值、投资等。（属于页面统计，在相关的成功页面调用）

#define BI_VALUE_TRANSACTION_RECHARGE   @"recharge" // 交易类型-充值
#define BI_VALUE_TRANSACTION_INVEST       @"invest" // 交易类型-投资
#define BI_VALUE_TRANSACTION_WITHDRAW  @"withdraw" // 交易类型-提现

#define GET_EXCEPTION @"NA"

#endif /* BIReportDefine_h */

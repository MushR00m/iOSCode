//
//  JYHTTPManager.h
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^JYHTTPManagerFinishBlock)(NSDictionary *resultInfo);


@interface NAFHTTPManager : NSObject

+ (instancetype)sharedInstance;

- (void)requestDeviceInfo:(NSDictionary *)deviceData appKey:(NSString *)appKey finishBlock:(JYHTTPManagerFinishBlock)block;

- (void)requestBusinessData:(NSDictionary *)businessData appKey:(NSString *)appKey fpid:(NSString *)fpid finishBlock:(JYHTTPManagerFinishBlock)block;

@end

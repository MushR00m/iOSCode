//
//  NWDAFReport.m
//  JYDeviceManager
//
//  Created by yangmengge on 16/8/30.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import "NAFReportUtils.h"
#import "NAFHTTPManager.h"
#import "NAFReportDefine.h"
#import <UIKit/UIKit.h>
#import "UIDevice+NAFHardware.h"
#import "NAFDeviceStorage.h"
#import "NAFGlobal.h"

#define BIREPORT_VERSION @"1.0"

@implementation NAFReportUtils

+ (NSString *)version
{
    return BIREPORT_VERSION;
}

#pragma mark - Public Methods

+ (void)initWithAPPKey:(NSString *)key
{
    [self initWithAPPKey:key data:[self initDeviceParams]];
}

+ (void)initWithAPPKey:(NSString *)key data:(NSDictionary *)data
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if (data) {
        [params setDictionary:data];
    }
    [params addEntriesFromDictionary:data];
    [NAFGlobal sharedInstance].appkey = key;
    [[NAFHTTPManager sharedInstance] requestDeviceInfo:params appKey:key finishBlock:^(NSDictionary *resultInfo) {
    }];
}

+ (void)trackWithName:(NSString *)name data:(NSDictionary *)data
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if (data) {
        [params setDictionary:data];
    }
    
//    NSString *userId = [data objectForKey:BI_KEY_UID];
//    [params setObject:BI_SAFE_STRING([self aesEntry:userId]) forKey:BI_KEY_UID];
//    
//    // 渠道类型。若为空则为:na|na|na|na|na|na
//    NSString *cid = [data objectForKey:BI_KEY_CID];
//    [params setObject:BI_SAFE_STRING(cid) forKey:BI_KEY_CID];
    
    // 请求时间戳。请求时间戳以客户端发送请求为准，格式为unixtime
    NSTimeInterval wInterval = [[NSDate date] timeIntervalSince1970];
    long long wTotalMilliseconds = wInterval * 1000;
    [params setObject:[NSString stringWithFormat:@"%lld", wTotalMilliseconds] forKey:BI_KEY_TIME];
    [params addEntriesFromDictionary:[self baseParams]];
    
    [[NAFHTTPManager sharedInstance] requestBusinessData:params appKey:[NAFGlobal sharedInstance].appkey fpid:[NAFGlobal sharedInstance].fpid finishBlock:^(NSDictionary *resultInfo) {
      

    }];
}


/** 基本参数 */
+ (NSDictionary *)baseParams
{
    static dispatch_once_t one;
    static NSMutableDictionary *dict;
    
    dispatch_once(&one, ^{
        dict = [NSMutableDictionary dictionary];
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_cfuuid]) forKey:BI_KEY_UUID]; // 客户唯一标识符，md5(uuid)
        [dict setObject:@"ios" forKey:BI_KEY_OS]; // 操作系统。移动端必须加在URL中
        [dict setObject:[UIDevice systemVersion] forKey:BI_KEY_OSVER]; // 操作系统版本。移动端必须加在URL中
        [dict setObject:[[UIApplication sharedApplication] appVersion] forKey:BI_KEY_AV]; // app版本号。格式：4.6.1
        [dict setObject:[[UIApplication sharedApplication] appBundleId] forKey:BI_KEY_APPID]; // app应用id
        [dict setObject:NAF_SAFE_STRING([[UIDevice currentDevice] machineModel]) forKey:BI_KEY_DEVICE]; // 手机型号。iPhone6s
        // screen resolution
        CGSize screenSize = [[UIScreen mainScreen] sizeInPixel];
        [dict setObject:[NSString stringWithFormat:@"%d_%d", (int)screenSize.width, (int)screenSize.height] forKey:BI_KEY_SR]; // 屏幕分辨率。格式：1920_1080
        [dict setObject:@"ios" forKey:BI_KEY_SRC]; // 来源。pc,ios,android,wap
        [dict setObject:NAF_SAFE_STRING([NAFTelephoneUtils carrierName]) forKey:BI_KEY_OPERATOR]; // 运营商
    });
    
    [dict setObject:NAF_SAFE_STRING([NAFTelephoneUtils netWorkType]) forKey:BI_KEY_NETTYPE]; // 网络类型
    // 原始设备id  原始设备id（加密）（AES128/ECB） ios：idfa， android：device_id
    [dict setObject:NAF_SAFE_STRING([UIDevice idfaString]) forKey:BI_KEY_RID];
    [dict setObject:NAF_SAFE_STRING([UIDevice macString]) forKey:BI_KEY_MA];


//    [dict setObject:NAF_SAFE_STRING([self aesEntry:[self idfaString]]) forKey:BI_KEY_RID];
//    // mac地址  设备的mac地址（加密）（AES128/ECB）
//    [dict setObject:NAF_SAFE_STRING([self aesEntry:[self macString]]) forKey:BI_KEY_MA];
    //新增字断
    [dict setObject:NAF_SAFE_STRING([UIDevice jy_cellIPAddress]) forKey:@"ip"]; //真实IP
    [dict setObject:NAF_SAFE_STRING([UIDevice agentIP]) forKey:@"aip"]; //代理IP
    return dict;
}


+ (NSDictionary *)initDeviceParams
{
    static dispatch_once_t one;
    static NSMutableDictionary *dict;
    dispatch_once(&one, ^{
        dict = [NSMutableDictionary dictionary];
        [dict setObject:NAF_SAFE_STRING([[UIDevice currentDevice] machineModelName]) forKey:AF_KEY_DEVICE]; // 手机型号。iPhone6s
        [dict setObject:@"ios" forKey:AF_KEY_OS]; // 操作系统
        [dict setObject:[UIDevice systemVersion] forKey:BI_KEY_OSVER]; // 操作系统版本。移动端必须加在URL中
        [dict setObject:[UIDevice idfaString] forKey:AF_KEY_IDFA]; //广告追踪id
        
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_carrier]) forKey:@"operator"]; //运营商
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_isJailBreak]) forKey:@"break"]; //是否越狱或者刷机
        // 请求时间戳。请求时间戳以客户端发送请求为准，格式为unixtime
        NSTimeInterval wInterval = [[NSDate date] timeIntervalSince1970];
        long long wTotalMilliseconds = wInterval * 1000;
        [dict setObject:[NSString stringWithFormat:@"%lld", wTotalMilliseconds] forKey:BI_KEY_TIME]; //请求时手机时间
        NSTimeZone *zone = [NSTimeZone systemTimeZone]; // 获得系统的时区
        [dict setObject:NAF_SAFE_STRING(zone.name) forKey:@"tz"]; //时区
        [dict setObject:NAF_SAFE_STRING([UIDevice getCurrentLanguage]) forKey:@"langue"]; //语言
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_resolution]) forKey:@"sr"]; //分辨率
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"bright"]; //亮度
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_networkType]) forKey:@"nettype"]; //网络类型
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_cellMacAddress]) forKey:@"ma"]; //Mac地址
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"dns"]; //dns地址
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_totalStorage]) forKey:@"capacity"]; //原始存储空间大小
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_totalMemory]) forKey:@"memory"]; //原始内存大小
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"app_ori"]; //系统自带app数量 //TODO
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"applist"]; //App列表 //TODO
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"btoothid"]; //蓝牙地址
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_cpuCount]) forKey:@"cpu_type"]; //Cpu型号
        
        //业务数据
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_cellIPAddress]) forKey:@"ip"]; //真实IP
        [dict setObject:NAF_SAFE_STRING([UIDevice agentIP]) forKey:@"aip"]; //代理IP
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"appid"]; //App类型
        [dict setObject:NAF_SAFE_STRING(@"") forKey:@"av"]; //App版本
        [dict setObject:NAF_SAFE_STRING(@"open") forKey:@"t"]; //动作方式  //外面
        [dict setObject:NAF_SAFE_STRING(@"ios") forKey:@"src"]; //来源
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_isSimulator]) forKey:@"emulator"]; //是否模拟器打开
        [dict setObject:NAF_SAFE_STRING([UIDevice jy_cfuuid]) forKey:@"uuid"]; //之前上报唯一id
        });
    return dict;
}

+ (NSString *)uuid
{
    CFUUIDRef uuidObject = CFUUIDCreate(kCFAllocatorDefault);
    NSString *uuidString = (NSString *)CFBridgingRelease(CFUUIDCreateString(kCFAllocatorDefault, uuidObject));
    CFRelease(uuidObject);
    return uuidString;
}

@end

//
//  NAFGlobal.h
//  NAntiFraudSDK
//
//  Created by yangmengge on 16/8/31.
//  Copyright © 2016年 niwodai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NAFGlobal : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, copy) NSString *appkey;
@property (nonatomic, copy) NSString *fpid;
@property (nonatomic, copy) NSString *sessionid;

@end

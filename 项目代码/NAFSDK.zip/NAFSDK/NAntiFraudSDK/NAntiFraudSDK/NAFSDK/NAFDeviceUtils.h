//
//  JYDeviceUtils.h
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NAFDeviceUtils : NSObject

+ (NSDictionary *)collectDeviceInfo;

@end

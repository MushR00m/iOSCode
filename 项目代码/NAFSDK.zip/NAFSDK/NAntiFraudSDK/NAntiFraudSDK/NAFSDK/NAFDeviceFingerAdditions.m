//
//  JY_DeviceFingerAdditions.m
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/4.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import "NAFDeviceFingerAdditions.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSArray (NAF_Additions)

- (id)jy_safeObjectAtIndex:(NSUInteger)index
{
    if (index < self.count) {
        return [self objectAtIndex:index];
    } else {
#if DEBUG_ASSERT
        NSAssert(NO, @"数组越界");
#endif
    }
    
    return nil;
}

- (NSArray *)jy_uniqueArray
{
    NSMutableArray *uniqeArr = [NSMutableArray array];
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        if (![uniqeArr containsObject:obj]) {
            [uniqeArr jy_safeAddObject:obj];
        }
    }];
    return uniqeArr;
}

@end


//
// NSMutableArray
//
@implementation NSMutableArray (NAF_Additions)

- (void)jy_safeAddObject:(id)object
{
    if (object) {
        [self addObject:object];
    } else {
#if DEBUG_ASSERT
        NSAssert(NO, @"不能添加nil Object");
#endif
    }
}

- (void)jy_safeAddNilObject
{
    [self addObject:[NSNull null]];
}

- (void)jy_safeInsertObject:(id)anObject atIndex:(NSUInteger)index
{
    if (anObject) {
        [self insertObject:anObject atIndex:index];
    } else {
#if DEBUG_ASSERT
        NSAssert(NO, @"不能添加nil Object");
#endif
    }
}

@end



//
// NSMutableDictionary
//
@implementation NSMutableDictionary (NAF_Additions)

- (void)jy_safeSetObject:(id)anObject forKey:(id)aKey
{
    if (anObject && aKey) {
        [self setObject:anObject forKey:aKey];
    } else {
#if DEBUG_ASSERT
        if (anObject == nil) {
            NSAssert(NO, @"不能添加nil Object");
        }
        else if (aKey == nil) {
            NSAssert(NO, @"key不能为nil");
        }
#endif
    }
}

- (void)jy_safeSetValue:(id)value forKey:(NSString *)key
{
    if (key)
    {
        [self setValue:value forKey:key];
    } else {
#if DEBUG_ASSERT
        if (value == nil) {
            NSAssert(NO, @"不能添加nil value");
        }
        else if (key == nil) {
            NSAssert(NO, @"key不能为nil");
        }
#endif
    }
}

@end

@implementation NSDictionary (NAF_Additions)

- (NSString *)jy_stringForKey:(NSString *)key
{
    if (key) {
        NSObject *obj = [self objectForKey:key];
        if (obj) {
            return [obj description];
        }
    }
    return @"";
}

- (NSInteger)jy_integerForKey:(NSString *)key
{
    if (key) {
        return [[self objectForKey:key] integerValue];
    }
    return 0;
}

@end

@implementation NSString (NAF_Additions)

- (NSString*) sha1
{
    const char *cstr = [self cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:self.length];
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    CC_SHA1(data.bytes, data.length, digest);
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}

- (NSString *)obfuscate:(NSString *)string withKey:(NSString *)key
{
    // Create data object from the string
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    // Get pointer to data to obfuscate
    char *dataPtr = (char *) [data bytes];
    
    // Get pointer to key data
    char *keyData = (char *) [[key dataUsingEncoding:NSUTF8StringEncoding] bytes];
    
    // Points to each char in sequence in the key
    char *keyPtr = keyData;
    int keyIndex = 0;
    
    // For each character in data, xor with current value in key
    for (int x = 0; x < [data length]; x++)
    {
        // Replace current character in data with
        // current character xor'd with current key value.
        // Bump each pointer to the next character
        // *dataPtr = *dataPtr++ ^ *keyPtr++;
        *dataPtr = *dataPtr ^ *keyPtr;
        dataPtr++;
        keyPtr++;
        
        // If at end of key data, reset count and
        // set key pointer back to start of key value
        if (++keyIndex == [key length])
            keyIndex = 0, keyPtr = keyData;
    }
    
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

@end
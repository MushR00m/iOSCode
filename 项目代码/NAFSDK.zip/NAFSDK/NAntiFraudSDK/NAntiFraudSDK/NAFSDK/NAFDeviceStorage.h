//
//  JYDeviceStorage.h
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NAFDeviceStorage : NSObject

+ (instancetype)sharedInstance;

- (BOOL)saveDeviceId:(NSString *)deviceId;

- (BOOL)saveSessionId:(NSString *)sessionId;

- (BOOL)saveCFUUID:(NSString *)cfuuid;

- (BOOL)saveAppkey:(NSString *)appkey;

- (NSString *)getDeviceId;

- (NSString *)getSessionId;

- (NSString *)getCFUUID;

- (NSString *)getAppkey;

- (void)clearDeviceId;

- (void)clearSessionId;

- (void)clearCFUUID;

- (void)clearAPPKEY;

@end

//
//  NSData+Encryption.h
//  NWDBase
//
//  Created by qmwang on 16/3/31.
//  Copyright © 2016年 qmwang. All rights reserved.
//

#import <Foundation/Foundation.h>

//
// AES/ECB/PKCS7Padding 加解密算法
//
// http://www.vpabo.com/post/kai-fa/aesjia-mi
//
@interface NSData (Encryption)

// 加密（ECB/PKCS7Padding）
- (NSData *)AES256EncryptWithKey:(NSString *)key;
// 解密（ECB/PKCS7Padding）
- (NSData *)AES256DecryptWithKey:(NSString *)key;

@end

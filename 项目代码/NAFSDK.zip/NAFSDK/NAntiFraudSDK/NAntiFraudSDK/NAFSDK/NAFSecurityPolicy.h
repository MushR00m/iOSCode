//
//  JYSecurityPolicy.h
//  JYDeviceManager
//
//  Created by chensongqi on 16/8/17.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NAFSecurityPolicy : NSObject

@property (nonatomic, assign) BOOL allowInvalidCertificates;
@property (nonatomic, assign) BOOL validatesDomainName;
@property (nonatomic, assign) BOOL validatesCertificateChain;

- (BOOL)evaluateServerTrust:(SecTrustRef)serverTrust
                  forDomain:(NSString *)domain;

@end

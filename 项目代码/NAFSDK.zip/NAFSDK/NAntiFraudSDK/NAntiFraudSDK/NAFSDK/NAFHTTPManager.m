//
//  JYHTTPManager.m
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

// 上报基地址
#if DEBUG
//#define NAF_ANTIFRAUD_URL_STRING         (@"http://10.15.235.175:9200")
#define NAF_ANTIFRAUD_URL_STRING         (@"http://specter.niwodai.net")
#else
#define NAF_ANTIFRAUD_URL_STRING         (@"https://specter.niwodai.com")
#endif


// 最大并发数
#define DEVICEFINGER_MAX_CONCURRENT         (3)

// 请求超时时间（秒）
#define DEVICEFINGER_TIMEOUT_INTERVAL       (60)

// 网络请求失败重试次数
#define DEVICEFINGER_MAX_RETYCOUNT         (3)
#define BIREPORT_AES_KEY (__KEY_VALUE)


#import "NAFHTTPManager.h"
#import "NAFDeviceFingerAdditions.h"
#import "NAFNetworkReachabilityManager.h"
#import "NAFSecurityPolicy.h"
#import "NSData+Encryption.h"
#import "NAFDeviceStorage.h"
#import "NAFReportDefine.h"
#import "NAFGlobal.h"

@interface NAFHTTPManager() <NSURLSessionDataDelegate>

@property (nonatomic, strong, nullable) NSTimer *retryTimer;
@property (nonatomic, strong, nullable) NSURLSession *requestSession;

@property (nonatomic, assign) NSInteger deviceInfoRetryCount;
@property (nonatomic, assign) NSInteger bussinessRetryCount;

/** 设备信息请求，有网络后重试 */
@property (nonatomic, assign) BOOL devicdInfoReachableRetry;
/** 用户信息请求，有网络后重试 */
@property (nonatomic, assign) BOOL userInfoReachableRetry;

@property (nonatomic, copy) NSString *appKey;
@property (nonatomic, copy) NSString *deviceId;
@property (nonatomic, copy) NSDictionary *deviceDataDict;

@property (nonatomic, copy) JYHTTPManagerFinishBlock deviceInfoBlock;
@property (nonatomic, strong) NAFNetworkReachabilityManager *reachabilityManager;

@property (nonatomic, strong) NSMutableData *deviceInfoData;
@property (nonatomic, strong) NSMutableData *businessData;

@property (nonatomic, strong) NSURLSessionTask *deviceInfoTask;
@property (nonatomic, strong) NSURLSessionTask *bussinessTask;

@property (nonatomic, strong) NSHTTPURLResponse *deviceInfoResponse;
@property (nonatomic, strong) NSHTTPURLResponse *bussinessResponse;

@property (nonatomic, strong) NAFSecurityPolicy *securityPolicy;

@property (nonatomic, assign) BOOL isFirstCheckNetworkStatus;
@property (nonatomic, strong) NAFDeviceStorage *deviceStorage;

@end

@implementation NAFHTTPManager

static NAFHTTPManager *_instance;
static NSString *__KEY_VALUE = nil;

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[NAFHTTPManager alloc] init];
        _instance.deviceStorage = [NAFDeviceStorage sharedInstance];
    });
    return _instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initObfuscator];
        self.devicdInfoReachableRetry = NO;
        self.userInfoReachableRetry = NO;
        self.isFirstCheckNetworkStatus = YES;
        self.deviceInfoRetryCount = 0;
        self.bussinessRetryCount = 0;
        
        self.securityPolicy = [[NAFSecurityPolicy alloc] init];
        self.securityPolicy.allowInvalidCertificates = NO;
        self.securityPolicy.validatesDomainName = YES;
        self.securityPolicy.validatesCertificateChain = NO;

        self.deviceInfoData = [[NSMutableData alloc] init];
        self.businessData = [[NSMutableData alloc] init];
        
        [self initRequestSession];
        
        // 网络连通监测
        [self initReachability];
    }
    return self;
}

-(void)initObfuscator
{
    //  经过混淆的AES密钥
//    unsigned char obfuscatedKey[] = {0X15, 0X0F, 0X0D, 0X01, 0X13, 0X4A, 0X77, 0X09, 0X56, 0X30, 0X21, 0X04, 0X0D, 0X0A, 0X01, 0X09};
//    unsigned int obfuscatedKey_len = 16;
//    NSString *obfuscator = [NSStringFromClass([self class]) sha1];
//
//    NSData *obfuscatedData = [NSData dataWithBytes:obfuscatedKey length:obfuscatedKey_len];
//    NSString *obfuscatedStr = [[NSString alloc] initWithData:obfuscatedData encoding:NSUTF8StringEncoding];
//
//    __KEY_VALUE = [obfuscator obfuscate:obfuscatedStr withKey:obfuscator];
    __KEY_VALUE = @"pil7wyE1dVD58239";
}

- (void)initRequestSession
{
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration ephemeralSessionConfiguration];
    sessionConfiguration.HTTPMaximumConnectionsPerHost = DEVICEFINGER_MAX_CONCURRENT;
    sessionConfiguration.timeoutIntervalForResource = DEVICEFINGER_TIMEOUT_INTERVAL;
    sessionConfiguration.timeoutIntervalForRequest = DEVICEFINGER_TIMEOUT_INTERVAL;
    sessionConfiguration.requestCachePolicy = NSURLRequestReloadIgnoringCacheData;
    sessionConfiguration.allowsCellularAccess = YES;
    self.requestSession = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:self delegateQueue:[NSOperationQueue mainQueue]];
}

- (void)initReachability
{
    self.reachabilityManager = [NAFNetworkReachabilityManager sharedManager];
    // 监测网络连通性变化
    [self.reachabilityManager startMonitoring];
    __weak __typeof(self) weakSelf = self;
    [self.reachabilityManager setReachabilityStatusChangeBlock:^(JYNetworkReachabilityStatus status) {
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf checkNetworkStatus];
    }];
}

- (void)requestDeviceInfoError
{
    if (self.reachabilityManager.reachable) {
        self.deviceInfoRetryCount++;
        [self requestDeviceInfo:self.deviceDataDict
                         appKey:self.appKey
                    finishBlock:self.deviceInfoBlock
                     retryCount:self.deviceInfoRetryCount];
    } else {
        self.devicdInfoReachableRetry = YES;
    }
}

#pragma mark - Quere

- (void)checkNetworkStatus
{
    if (self.isFirstCheckNetworkStatus) {
        self.isFirstCheckNetworkStatus = NO;
        return;
    }
    if (self.reachabilityManager.reachable) {
        if (self.devicdInfoReachableRetry) {
            if (self.deviceInfoRetryCount < DEVICEFINGER_MAX_RETYCOUNT) {
                self.deviceInfoRetryCount++;
                [self requestDeviceInfo:self.deviceDataDict
                                 appKey:self.appKey
                            finishBlock:self.deviceInfoBlock
                             retryCount:self.deviceInfoRetryCount];
            }
        }
    }
}

#pragma mark - Request

- (void)requestDeviceInfo:(NSDictionary *)deviceData appKey:(NSString *)appKey finishBlock:(JYHTTPManagerFinishBlock)block;
{
    self.appKey = appKey;
    self.deviceDataDict = deviceData;
    self.deviceInfoBlock = block;
    [self requestDeviceInfo:deviceData appKey:appKey finishBlock:block retryCount:0];
}

//
- (void)requestDeviceInfo:(NSDictionary *)deviceData appKey:(NSString *)appKey finishBlock:(JYHTTPManagerFinishBlock)block retryCount:(NSInteger)retryCount
{
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] initWithDictionary:deviceData];
    [parameters jy_safeSetObject:[self.deviceStorage getDeviceId] forKey:@"fpid"];
    [parameters jy_safeSetObject:appKey forKey:@"appkey"];
    NSURL *url = [NSURL URLWithString:NAF_ANTIFRAUD_URL_STRING];
    NSMutableURLRequest *mutableRequest = [NSMutableURLRequest requestWithURL:url];
    [mutableRequest setHTTPMethod:@"POST"];
    NSMutableString *bodyStr = [[NSMutableString alloc] init];
    for (NSString *someKey in parameters) {
        NSString *someValue = [parameters objectForKey:someKey];
        NSString *someStr = [NSString stringWithFormat:@"%@=%@",someKey,someValue];
        [bodyStr appendFormat:@"%@&",someStr];
    }

    NSString *inputString = [bodyStr substringToIndex:bodyStr.length-1];
    NSString *aesEntryString = [self aesEntry:inputString];
    [mutableRequest setHTTPBody:[aesEntryString dataUsingEncoding:NSUTF8StringEncoding]];
    self.deviceInfoTask = [self.requestSession dataTaskWithRequest:mutableRequest];
    [self.deviceInfoTask resume];
}

- (void)requestBusinessData:(NSDictionary *)businessData appKey:(NSString *)appKey fpid:(NSString *)fpid finishBlock:(JYHTTPManagerFinishBlock)block
{
    [self requestBusinessData:businessData appKey:appKey fpid:fpid finishBlock:block retryCount:0];
}

- (void)requestBusinessData:(NSDictionary *)businessData  appKey:(NSString *)appKey fpid:(NSString *)fpid finishBlock:(JYHTTPManagerFinishBlock)block  retryCount:(NSInteger)retryCount
{
    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] initWithDictionary:businessData];
    [parameters jy_safeSetObject:appKey forKey:@"appkey"];
    [parameters jy_safeSetObject:fpid forKey:@"fpid"];
    [parameters jy_safeSetObject:[NAFGlobal sharedInstance].sessionid forKey:@"sessionid"];
    NSURL *url = [NSURL URLWithString:NAF_ANTIFRAUD_URL_STRING];
    NSMutableURLRequest *mutableRequest = [NSMutableURLRequest requestWithURL:url];
    [mutableRequest setHTTPMethod:@"POST"];
    NSMutableString *bodyStr = [[NSMutableString alloc] init];
    for (NSString *someKey in parameters) {
        NSString *someValue = [parameters objectForKey:someKey];
        NSString *someStr = [NSString stringWithFormat:@"%@=%@",someKey,someValue];
        [bodyStr appendFormat:@"%@&",someStr];
    }
    NSString *inputString = [bodyStr substringToIndex:bodyStr.length-1];
    NSString *aesEntryString = [self aesEntry:inputString];
    [mutableRequest setHTTPBody:[aesEntryString dataUsingEncoding:NSUTF8StringEncoding]];
    self.bussinessTask = [self.requestSession dataTaskWithRequest:mutableRequest];
    [self.bussinessTask resume];
}


- (void)deviceInfoRequestError
{
    if (self.deviceInfoRetryCount < DEVICEFINGER_MAX_RETYCOUNT) {
        [self requestDeviceInfoError];
    } else {
        DFLog(@"requestDeviceInfo  超过最大失败次数");
    }
}

- (void)deviceInfoRequestSuccess
{
    NSError *jsonError;
    NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:self.deviceInfoData options:NSJSONReadingMutableContainers error:&jsonError];
    if (jsonError == nil) {
        NSNumber *retCode = [responseDict objectForKey:@"status"];
        if (retCode.integerValue == 1) {
            //存储deviceId
            NSDictionary *data = [responseDict objectForKey:@"data"];
            NSString *deviceId = [data objectForKey:@"fpid"];
            NSString *sessionid = [data objectForKey:@"sessionid"];
            [NAFGlobal sharedInstance].fpid = deviceId;
            [NAFGlobal sharedInstance].sessionid = sessionid;
            [self.deviceStorage saveDeviceId:deviceId];

            if (self.deviceInfoBlock && ![self.deviceInfoBlock isEqual:[NSNull null]]) {
                self.deviceInfoBlock([responseDict objectForKey:@"data"]);
            }
        }
       DFLog(@"---- responseDict = %@",responseDict);
    } else {
        DFLog(@"deviceInfoData response json serialization error = %@",jsonError);
    }
    
}

- (void)bussinessRequestError
{
    NSLog(@"bussinessRequestError");
}

- (void)bussinessRequestSuccess
{
    NSError *jsonError;
    NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:self.businessData options:NSJSONReadingMutableContainers error:&jsonError];
    if (jsonError == nil) {
        NSLog(@"---- businessData responseDict = %@",responseDict);
    } else {
        NSLog(@"businessData response json serialization error = %@",jsonError);
    }
}


#pragma mark - Delegate

/*
 NSURLSessionAuthChallengeUseCredential = 0,                     使用证书
 NSURLSessionAuthChallengePerformDefaultHandling = 1,            忽略证书(默认的处理方式)
 NSURLSessionAuthChallengeCancelAuthenticationChallenge = 2,     忽略书证, 并取消这次请求
 NSURLSessionAuthChallengeRejectProtectionSpace = 3,            拒绝当前这一次, 下一次再询问
 */

- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * __nullable credential))completionHandler {
    
    NSURLSessionAuthChallengeDisposition disposition = NSURLSessionAuthChallengePerformDefaultHandling;
    __block NSURLCredential *credential = nil;
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        if ([self.securityPolicy evaluateServerTrust:challenge.protectionSpace.serverTrust forDomain:challenge.protectionSpace.host]) {
            credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
            if (credential) {
                disposition = NSURLSessionAuthChallengeUseCredential;
            } else {
                disposition = NSURLSessionAuthChallengePerformDefaultHandling;
            }
        } else {
            disposition = NSURLSessionAuthChallengeCancelAuthenticationChallenge;
        }
    } else {
        disposition = NSURLSessionAuthChallengePerformDefaultHandling;
    }
    
    if (completionHandler) {
        completionHandler(disposition, credential);
    }
}

- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition disposition))completionHandler {
    if (dataTask == self.bussinessTask) {
        //清空数据
        [self.businessData resetBytesInRange:NSMakeRange(0, self.businessData.length)];
        [self.businessData setLength:0];
        self.bussinessResponse = (NSHTTPURLResponse *)response;
    } else if (dataTask == self.deviceInfoTask) {
        //清空数据
        [self.deviceInfoData resetBytesInRange:NSMakeRange(0, self.deviceInfoData.length)];
        [self.deviceInfoData setLength:0];
        self.deviceInfoResponse = (NSHTTPURLResponse *)response;
    }
    completionHandler(NSURLSessionResponseAllow);
}

- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    if (dataTask == self.deviceInfoTask) {
        //拼接数据
        [self.deviceInfoData appendData:data];
    } else if (dataTask == self.bussinessTask) {
        //拼接数据
        [self.businessData appendData:data];
    }
}

- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(nullable NSError *)error {
    if (task == self.deviceInfoTask) {
        if (error) {
            [self deviceInfoRequestError];
        } else {
            if ([self.deviceInfoResponse statusCode] == 200 || [self.bussinessResponse statusCode] == 304) {
                [self deviceInfoRequestSuccess];
            } else {
                [self deviceInfoRequestError];
            }
        }
    } else if (task == self.bussinessTask) {
        if (error) {
            [self bussinessRequestError];
        } else {
            if ([self.bussinessResponse statusCode] == 200 || [self.bussinessResponse statusCode] == 304) {
                [self bussinessRequestSuccess];
            } else {
                [self bussinessRequestError];
            }
        }
    }
}


- (NSString *)aesEntry:(NSString *)value
{
    if (value.length) {
        NSData *valueData = [value dataUsingEncoding:NSUTF8StringEncoding];
        NSData *encryptData = [valueData AES256EncryptWithKey:BIREPORT_AES_KEY];
        NSString *resultStr = [encryptData base64Encoding];
        return resultStr;
    }
    return value;
}

@end

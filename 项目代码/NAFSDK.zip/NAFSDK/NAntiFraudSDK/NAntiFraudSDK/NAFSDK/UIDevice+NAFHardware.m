//
//  UIDevice+JYHardware.m
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import "UIDevice+NAFHardware.h"
#import <AdSupport/ASIdentifierManager.h>

#import <sys/utsname.h>
#import <ifaddrs.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#import <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <sys/ioctl.h>
#import <sys/stat.h>
#import <mach-o/arch.h>

#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "NAFDeviceStorage.h"
#import "NAFReportDefine.h"
#import "NAFNetworkReachabilityManager.h"

#define NAF_IS_OS_6_OR_EARLIER         ([[[UIDevice currentDevice] systemVersion] floatValue] < 6.99)

@implementation UIDevice (NAF_Hardware)

+ (NSString *)systemName {
    static NSString *version;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        version = [UIDevice currentDevice].systemName;
    });
    return version;
}

+ (NSString *)systemVersion {
    static NSString *version;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        version = [UIDevice currentDevice].systemVersion;
    });
    return version;
}

- (NSString *)machineModel {
    static dispatch_once_t one;
    static NSString *model;
    dispatch_once(&one, ^{
        size_t size;
        sysctlbyname("hw.machine", NULL, &size, NULL, 0);
        char *machine = malloc(size);
        sysctlbyname("hw.machine", machine, &size, NULL, 0);
        model = [NSString stringWithUTF8String:machine];
        free(machine);
    });
    return model;
}

- (NSString *)machineModelName {
    static dispatch_once_t one;
    static NSString *name;
    dispatch_once(&one, ^{
        NSString *model = [self machineModel];
        if (!model) return;
        NSDictionary *dic = @{
                              @"Watch1,1" : @"Apple Watch",
                              @"Watch1,2" : @"Apple Watch",
                              
                              @"iPod1,1" : @"iPod touch 1",
                              @"iPod2,1" : @"iPod touch 2",
                              @"iPod3,1" : @"iPod touch 3",
                              @"iPod4,1" : @"iPod touch 4",
                              @"iPod5,1" : @"iPod touch 5",
                              @"iPod7,1" : @"iPod touch 6",
                              
                              @"iPhone1,1" : @"iPhone 1G",
                              @"iPhone1,2" : @"iPhone 3G",
                              @"iPhone2,1" : @"iPhone 3GS",
                              @"iPhone3,1" : @"iPhone 4 (GSM)",
                              @"iPhone3,2" : @"iPhone 4",
                              @"iPhone3,3" : @"iPhone 4 (CDMA)",
                              @"iPhone4,1" : @"iPhone 4S",
                              @"iPhone5,1" : @"iPhone 5",
                              @"iPhone5,2" : @"iPhone 5",
                              @"iPhone5,3" : @"iPhone 5c",
                              @"iPhone5,4" : @"iPhone 5c",
                              @"iPhone6,1" : @"iPhone 5s",
                              @"iPhone6,2" : @"iPhone 5s",
                              @"iPhone7,1" : @"iPhone 6 Plus",
                              @"iPhone7,2" : @"iPhone 6",
                              @"iPhone8,1" : @"iPhone 6s",
                              @"iPhone8,2" : @"iPhone 6s Plus",
                              
                              @"iPad1,1" : @"iPad 1",
                              @"iPad2,1" : @"iPad 2 (WiFi)",
                              @"iPad2,2" : @"iPad 2 (GSM)",
                              @"iPad2,3" : @"iPad 2 (CDMA)",
                              @"iPad2,4" : @"iPad 2",
                              @"iPad2,5" : @"iPad mini 1",
                              @"iPad2,6" : @"iPad mini 1",
                              @"iPad2,7" : @"iPad mini 1",
                              @"iPad3,1" : @"iPad 3 (WiFi)",
                              @"iPad3,2" : @"iPad 3 (4G)",
                              @"iPad3,3" : @"iPad 3 (4G)",
                              @"iPad3,4" : @"iPad 4",
                              @"iPad3,5" : @"iPad 4",
                              @"iPad3,6" : @"iPad 4",
                              @"iPad4,1" : @"iPad Air",
                              @"iPad4,2" : @"iPad Air",
                              @"iPad4,3" : @"iPad Air",
                              @"iPad4,4" : @"iPad mini 2",
                              @"iPad4,5" : @"iPad mini 2",
                              @"iPad4,6" : @"iPad mini 2",
                              @"iPad4,7" : @"iPad mini 3",
                              @"iPad4,8" : @"iPad mini 3",
                              @"iPad4,9" : @"iPad mini 3",
                              @"iPad5,1" : @"iPad mini 4",
                              @"iPad5,2" : @"iPad mini 4",
                              @"iPad5,3" : @"iPad Air 2",
                              @"iPad5,4" : @"iPad Air 2",
                              
                              @"i386" : @"Simulator x86",
                              @"x86_64" : @"Simulator x64",
                              };
        name = dic[model];
        if (!name) name = model;
    });
    return name;
}

+ (NSString *) macString
{
    
    int 				mib[6];
    size_t 				len;
    char 				*buf;
    unsigned char	 	*ptr;
    struct if_msghdr 	*ifm;
    struct sockaddr_dl 	*sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1\n");
        return NULL;
    }
    
    if ((buf = malloc(len)) == NULL) {
        printf("Could not allocate memory. error!\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        free(buf);
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    //	NSString *macString = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",
    //                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    NSString *macString = [NSString stringWithFormat:@"%02x%02x%02x%02x%02x%02x",
                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    
    return macString;
}

+ (NSString *) idfaString
{
    
    NSBundle *adSupportBundle = [NSBundle bundleWithPath:@"/System/Library/Frameworks/AdSupport.framework"];
    [adSupportBundle load];
    
    if (adSupportBundle == nil) {
        return @"";
    }
    else{
        
        Class asIdentifierMClass = NSClassFromString(@"ASIdentifierManager");
        
        if(asIdentifierMClass == nil){
            return @"";
        }
        else{
            
            //for no arc
            //ASIdentifierManager *asIM = [[[asIdentifierMClass alloc] init] autorelease];
            //for arc
            ASIdentifierManager *asIM = [[asIdentifierMClass alloc] init];
            
            if (asIM == nil) {
                return @"";
            }
            else{
                
                if(asIM.advertisingTrackingEnabled){
                    return [asIM.advertisingIdentifier UUIDString];
                }
                else{
                    return [asIM.advertisingIdentifier UUIDString];
                }
            }
        }
    }
}

+ (NSString *)uuid
{
    CFUUIDRef uuidObject = CFUUIDCreate(kCFAllocatorDefault);
    NSString *uuidString = (NSString *)CFBridgingRelease(CFUUIDCreateString(kCFAllocatorDefault, uuidObject));
    CFRelease(uuidObject);
    return uuidString;
}

+ (NSString *)phoneNumber
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:@"SBFormattedPhoneNumber"];
}

/**
 *  运营商
 *
 *  @return 中国联通
 */
+ (NSString *)carrier
{
    @try {
        CTTelephonyNetworkInfo *TelephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
        CTCarrier *Carrier = [TelephonyInfo subscriberCellularProvider];
        NSString *carrier = [Carrier carrierName];
        if (NAF_CHECK_VALID_STRING(carrier)) {
            return carrier;
        } else {
            return GET_EXCEPTION;
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  屏幕分辨率
 *
 *  @return 375x667
 */
+ (NSString *)jy_resolution;
{
    @try {
        static dispatch_once_t one;
        static CGSize size;
        dispatch_once(&one, ^{
            size = CGSizeZero;
            if ([[UIScreen mainScreen] isEqual:self]) {
                NSString *model = [self _jy_deviceType];
                if ([model hasPrefix:@"iPhone"]) {
                    if ([model hasPrefix:@"iPhone1"]) size = CGSizeMake(320, 480);
                    else if ([model hasPrefix:@"iPhone2"]) size = CGSizeMake(320, 480);
                    else if ([model hasPrefix:@"iPhone3"]) size = CGSizeMake(640, 960);
                    else if ([model hasPrefix:@"iPhone4"]) size = CGSizeMake(640, 960);
                    else if ([model hasPrefix:@"iPhone5"]) size = CGSizeMake(640, 1136);
                    else if ([model hasPrefix:@"iPhone6"]) size = CGSizeMake(640, 1136);
                    else if ([model hasPrefix:@"iPhone7,1"]) size = CGSizeMake(1080, 1920);
                    else if ([model hasPrefix:@"iPhone7,2"]) size = CGSizeMake(750, 1334);
                    else if ([model hasPrefix:@"iPhone8,1"]) size = CGSizeMake(1080, 1920);
                    else if ([model hasPrefix:@"iPhone8,2"]) size = CGSizeMake(750, 1334);
                    else if ([model hasPrefix:@"iPhone8,4"]) size = CGSizeMake(640, 1136);
                } else if ([model hasPrefix:@"iPod"]) {
                    if ([model hasPrefix:@"iPod1"]) size = CGSizeMake(320, 480);
                    else if ([model hasPrefix:@"iPod2"]) size = CGSizeMake(320, 480);
                    else if ([model hasPrefix:@"iPod3"]) size = CGSizeMake(320, 480);
                    else if ([model hasPrefix:@"iPod4"]) size = CGSizeMake(640, 960);
                    else if ([model hasPrefix:@"iPod5"]) size = CGSizeMake(640, 1136);
                    else if ([model hasPrefix:@"iPod7"]) size = CGSizeMake(640, 1136);
                } else if ([model hasPrefix:@"iPad"]) {
                    if ([model hasPrefix:@"iPad1"]) size = CGSizeMake(768, 1024);
                    else if ([model hasPrefix:@"iPad2"]) size = CGSizeMake(768, 1024);
                    else if ([model hasPrefix:@"iPad3"]) size = CGSizeMake(1536, 2048);
                    else if ([model hasPrefix:@"iPad4"]) size = CGSizeMake(1536, 2048);
                    else if ([model hasPrefix:@"iPad5"]) size = CGSizeMake(1536, 2048);
                    else if ([model hasPrefix:@"iPad6,3"]) size = CGSizeMake(1536, 2048);
                    else if ([model hasPrefix:@"iPad6,4"]) size = CGSizeMake(1536, 2048);
                    else if ([model hasPrefix:@"iPad6,7"]) size = CGSizeMake(2048, 2732);
                    else if ([model hasPrefix:@"iPad6,8"]) size = CGSizeMake(2048, 2732);
                }
            }
            if (CGSizeEqualToSize(size, CGSizeZero)) {
                if ([self respondsToSelector:@selector(nativeBounds)]) {
                    size = [UIScreen mainScreen].nativeBounds.size;
                } else {
                    size = [UIScreen mainScreen].bounds.size;
                    size.width *= [UIScreen mainScreen].scale;
                    size.height *= [UIScreen mainScreen].scale;
                }
                if (size.height < size.width) {
                    CGFloat tmp = size.height;
                    size.height = size.width;
                    size.width = tmp;
                }
            }
        });
        NSString *resolution = [NSString stringWithFormat:@"%ld_%ld",(long)size.width,(long)size.height];
        return resolution;
    }
    @catch(NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  系统总存
 *
 *  @return 1015.66 MB
 */
+ (NSString *)jy_totalMemory
{
    @try {
        double totalMemory = 0.00;
        double allMemory = [[NSProcessInfo processInfo] physicalMemory];
        totalMemory = allMemory / (1024.0*1024.0);
        int toNearest = 256;
        int remainder = (int)totalMemory % toNearest;
        
        if (remainder >= toNearest / 2) {
            totalMemory = ((int)totalMemory - remainder) + 256;
        } else {
            totalMemory = (int)totalMemory - remainder;
        }
        
        if (totalMemory <= 0) {
            return GET_EXCEPTION;
        }
        return [NSString stringWithFormat:@"%.2f MB",totalMemory];
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  越狱标识
 *
 *  @return 1/0  1表示越狱
 */
// Jailbreak Check Definitions
#define NOTJAIL 4783242
#define CYDIA       @"MobileCydia"
#define OTHERCYDIA  @"Cydia"
#define OOCYDIA     @"afpd"
#define CYDIAPACKAGE    @"cydia://package/com.fake.package"
#define CYDIALOC        @"/Applications/Cydia.app"
#define HIDDENFILES     [NSArray arrayWithObjects:@"/Applications/RockApp.app",@"/Applications/Icy.app",@"/usr/sbin/sshd",@"/usr/bin/sshd",@"/usr/libexec/sftp-server",@"/Applications/WinterBoard.app",@"/Applications/SBSettings.app",@"/Applications/MxTube.app",@"/Applications/IntelliScreen.app",@"/Library/MobileSubstrate/DynamicLibraries/Veency.plist",@"/Library/MobileSubstrate/DynamicLibraries/LiveClock.plist",@"/private/var/lib/apt",@"/private/var/stash",@"/System/Library/LaunchDaemons/com.ikey.bbot.plist",@"/System/Library/LaunchDaemons/com.saurik.Cydia.Startup.plist",@"/private/var/tmp/cydia.log",@"/private/var/lib/cydia", @"/etc/clutch.conf", @"/var/cache/clutch.plist", @"/etc/clutch_cracked.plist", @"/var/cache/clutch_cracked.plist", @"/var/lib/clutch/overdrive.dylib", @"/var/root/Documents/Cracked/", nil]
#define JY_SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)

// Define the filesystem check
#define FILECHECK [NSFileManager defaultManager] fileExistsAtPath:
// Define the exe path
#define EXEPATH [[NSBundle mainBundle] executablePath]
// Define the plist path
#define PLISTPATH [[NSBundle mainBundle] infoDictionary]


// Failed jailbroken checks
enum {
    // Failed the Jailbreak Check
    KFJailbroken = 3429542,
    // Failed the OpenURL Check
    KFOpenURL = 321,
    // Failed the Cydia Check
    KFCydia = 432,
    // Failed the Inaccessible Files Check
    KFIFC = 47293,
    // Failed the plist check
    KFPlist = 9412,
    // Failed the Processes Check with Cydia
    KFProcessesCydia = 10012,
    // Failed the Processes Check with other Cydia
    KFProcessesOtherCydia = 42932,
    // Failed the Processes Check with other other Cydia
    KFProcessesOtherOCydia = 10013,
    // Failed the FSTab Check
    KFFSTab = 9620,
    // Failed the System() Check
    KFSystem = 47475,
    // Failed the Symbolic Link Check
    KFSymbolic = 34859,
    // Failed the File Exists Check
    KFFileExists = 6625,
} JailbrokenChecks;

+ (NSString *)jy_isJailBreak
{
    @try {
        // Is the device jailbroken?
        
        // Make an int to monitor how many checks are failed
        int motzart = 0;
        
        // Check if iOS 8 or lower
        if (JY_SYSTEM_VERSION_LESS_THAN(@"9.0")) {
            // URL Check
            if ([self _jy_urlCheck] != NOTJAIL) {
                // Jailbroken
                motzart += 3;
            }
        }
        
        // Cydia Check
        if ([self _jy_cydiaCheck] != NOTJAIL) {
            // Jailbroken
            motzart += 3;
        }
        
        // Inaccessible Files Check
        if ([self _jy_inaccessibleFilesCheck] != NOTJAIL) {
            // Jailbroken
            motzart += 2;
        }
        
        // Plist Check
        if ([self _jy_plistCheck] != NOTJAIL) {
            // Jailbroken
            motzart += 2;
        }
        
        // Check if iOS 8 or lower
        if (JY_SYSTEM_VERSION_LESS_THAN(@"9.0")) {
            // Processes Check
            if ([self _jy_processesCheck] != NOTJAIL) {
                // Jailbroken
                motzart += 2;
            }
            
            // FSTab Check
            if ([self _jy_fstabCheck] != NOTJAIL) {
                // Jailbroken
                motzart += 1;
            }
            
            // Shell Check
            if ([self _jy_systemCheck] != NOTJAIL) {
                // Jailbroken
                motzart += 2;
            }
        }
        
        // Symbolic Link Check
        if ([self _jy_symbolicLinkCheck] != NOTJAIL) {
            // Jailbroken
            motzart += 2;
        }
        
        // FilesExist Integrity Check
        if ([self _jy_filesExistCheck] != NOTJAIL) {
            // Jailbroken
            motzart += 2;
        }
        
        // Check if the Jailbreak Integer is 3 or more
        if (motzart >= 3) {
            // Jailbroken
            return @"1";
        }
        
        // Not Jailbroken
        return @"0";

    } @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

// UIApplication CanOpenURL Check
+ (int)_jy_urlCheck {
    @try {
        // Create a fake url for cydia
        NSURL *FakeURL = [NSURL URLWithString:CYDIAPACKAGE];
        // Return whether or not cydia's openurl item exists
        if ([[UIApplication sharedApplication] canOpenURL:FakeURL])
            return KFOpenURL;
        else
            return NOTJAIL;
    }
    @catch (NSException *exception) {
        // Error, return false
        return NOTJAIL;
    }
}

// Cydia Check
+ (int)_jy_cydiaCheck {
    @try {
        // Create a file path string
        NSString *filePath = CYDIALOC;
        // Check if it exists
        if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            // It exists
            return KFCydia;
        } else {
            // It doesn't exist
            return NOTJAIL;
        }
    }
    @catch (NSException *exception) {
        // Error, return false
        return NOTJAIL;
    }
}

// Inaccessible Files Check
+ (int)_jy_inaccessibleFilesCheck {
    @try {
        // Run through the array of files
        for (NSString *key in HIDDENFILES) {
            // Check if any of the files exist (should return no)
            if ([[NSFileManager defaultManager] fileExistsAtPath:key]) {
                // Jailbroken
                return KFIFC;
            }
        }
        
        // Shouldn't get this far, return jailbroken
        return NOTJAIL;
    }
    @catch (NSException *exception) {
        // Error, return false
        return NOTJAIL;
    }
}


// Plist Check
+ (int)_jy_plistCheck {
    @try {
        // Define the Executable name
        NSString *ExeName = EXEPATH;
        NSDictionary *ipl = PLISTPATH;
        // Check if the plist exists
        if ([FILECHECK ExeName] == FALSE || ipl == nil || ipl.count <= 0) {
            // Executable file can't be found and the plist can't be found...hmmm
            return KFPlist;
        } else {
            // Everything is good
            return NOTJAIL;
        }
    }
    @catch (NSException *exception) {
        // Error, return false
        return NOTJAIL;
    }
}

// Running Processes Check
+ (int)_jy_processesCheck {
    @try {
        // Make a processes array
        NSArray *processes = [self _jy_runningProcesses];
        
        // Check for Cydia in the running processes
        for (NSDictionary * dict in processes) {
            // Define the process name
            NSString *process = [dict objectForKey:@"ProcessName"];
            // If the process is this executable
            if ([process isEqualToString:CYDIA]) {
                // Return Jailbroken
                return KFProcessesCydia;
            } else if ([process isEqualToString:OTHERCYDIA]) {
                // Return Jailbroken
                return KFProcessesOtherCydia;
            } else if ([process isEqualToString:OOCYDIA]) {
                // Return Jailbroken
                return KFProcessesOtherOCydia;
            }
        }
        
        // Not Jailbroken
        return NOTJAIL;
    }
    @catch (NSException *exception) {
        // Error
        return NOTJAIL;
    }
}

// FSTab Size
+ (int)_jy_fstabCheck {
    @try {
        struct stat sb;
        stat("/etc/fstab", &sb);
        long long size = sb.st_size;
        if (size == 80) {
            // Not jailbroken
            return NOTJAIL;
        } else
            // Jailbroken
            return KFFSTab;
    }
    @catch (NSException *exception) {
        // Not jailbroken
        return NOTJAIL;
    }
}

// System() available
+ (int)_jy_systemCheck {
    @try {
        // See if the system call can be used
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        if (system(0)) {
            // Jailbroken
            return KFSystem;
        } else
            // Not Jailbroken
            return NOTJAIL;
#pragma clang diagnostic pop
        
    }
    @catch (NSException *exception) {
        // Not Jailbroken
        return NOTJAIL;
    }
}

// Symbolic Link available
+ (int)_jy_symbolicLinkCheck {
    @try {
        // See if the Applications folder is a symbolic link
        struct stat s;
        if (lstat("/Applications", &s) != 0) {
            if (s.st_mode & S_IFLNK) {
                // Device is jailbroken
                return KFSymbolic;
            } else
                // Not jailbroken
                return NOTJAIL;
        } else {
            // Not jailbroken
            return NOTJAIL;
        }
    }
    @catch (NSException *exception) {
        // Not Jailbroken
        return NOTJAIL;
    }
}

// FileSystem working correctly?
+ (int)_jy_filesExistCheck {
    @try {
        // Check if filemanager is working
        if (![FILECHECK [[NSBundle mainBundle] executablePath]]) {
            // Jailbroken and trying to hide it
            return KFFileExists;
        } else
            // Not Jailbroken
            return NOTJAIL;
    }
    @catch (NSException *exception) {
        // Not Jailbroken
        return NOTJAIL;
    }
}

+ (NSArray *)_jy_runningProcesses {
    // Define the int array of the kernel's processes
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
    size_t miblen = 4;
    
    // Make a new size and int of the sysctl calls
    size_t size = 0;
    int st;
    
    // Make new structs for the processes
    struct kinfo_proc * process = NULL;
    struct kinfo_proc * newprocess = NULL;
    
    // Do get all the processes while there are no errors
    do {
        // Add to the size
        size += (size / 10);
        // Get the new process
        newprocess = realloc(process, size);
        // If the process selected doesn't exist
        if (!newprocess){
            // But the process exists
            if (process){
                // Free the process
                free(process);
            }
            // Return that nothing happened
            return nil;
        }
        
        // Make the process equal
        process = newprocess;
        
        // Set the st to the next process
        st = sysctl(mib, (int)miblen, process, &size, NULL, 0);
        
    } while (st == -1 && errno == ENOMEM);
    
    // As long as the process list is empty
    if (st == 0){
        
        // And the size of the processes is 0
        if (size % sizeof(struct kinfo_proc) == 0){
            // Define the new process
            int nprocess = (int)(size / sizeof(struct kinfo_proc));
            // If the process exists
            if (nprocess){
                // Create a new array
                NSMutableArray * array = [[NSMutableArray alloc] init];
                // Run through a for loop of the processes
                for (int i = nprocess - 1; i >= 0; i--){
                    // Get the process ID
                    NSString * processID = [[NSString alloc] initWithFormat:@"%d", process[i].kp_proc.p_pid];
                    // Get the process Name
                    NSString * processName = [[NSString alloc] initWithFormat:@"%s", process[i].kp_proc.p_comm];
                    // Get the process Priority
                    NSString *processPriority = [[NSString alloc] initWithFormat:@"%d", process[i].kp_proc.p_priority];
                    // Get the process running time
                    NSDate   *processStartDate = [NSDate dateWithTimeIntervalSince1970:process[i].kp_proc.p_un.__p_starttime.tv_sec];
                    // Create a new dictionary containing all the process ID's and Name's
                    NSDictionary *dict = [[NSDictionary alloc] initWithObjects:[NSArray arrayWithObjects:processID, processPriority, processName, processStartDate, nil]
                                                                       forKeys:[NSArray arrayWithObjects:@"ProcessID", @"ProcessPriority", @"ProcessName", @"ProcessStartDate", nil]];
                    
                    // Add the dictionary to the array
                    [array addObject:dict];
                }
                // Free the process array
                free(process);
                
                // Return the process array
                return array;
                
            }
        }
    }
    
    // Free the process array
    free(process);
    
    // If no processes are found, return nothing
    return nil;
}


/**
 *   cpu数量
 *
 *  @return 2
 */
+ (NSString *)jy_cpuCount
{
    @try {
        NSUInteger cpuCount = [[NSProcessInfo processInfo] processorCount];
        if (cpuCount > 0) {
            return [NSString stringWithFormat:@"%ld",(long)cpuCount];
        } else {
            return GET_EXCEPTION;
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  idfa
 *
 *  @return 7E0535C8-4BAA-481C-AC35-EC5662DBBE02
 */
+ (NSString *)jy_identifierForAdvertising
{
    @try {
        NSBundle *adSupportBundle = [NSBundle bundleWithPath:@"/System/Library/Frameworks/AdSupport.framework"];
        [adSupportBundle load];
        if (adSupportBundle == nil) {
            return GET_EXCEPTION;
        } else {
            Class asIdentifierMClass = NSClassFromString(@"ASIdentifierManager");
            if(asIdentifierMClass == nil){
                return GET_EXCEPTION;
            } else {
                ASIdentifierManager *asIM = [[asIdentifierMClass alloc] init];
                if (asIM == nil) {
                    return GET_EXCEPTION;
                } else {
                    if (asIM.advertisingTrackingEnabled) {
                        return [asIM.advertisingIdentifier UUIDString];
                    } else {
                        return GET_EXCEPTION;
                    }
                }
            }
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  idfv
 *
 *  @return B14E3003-9639-49AB-B4A3-F047C7FC9020"
 */
+ (NSString *)jy_identifierForVendor
{
    @try {
        NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        if (NAF_CHECK_VALID_STRING(idfv)) {
            return idfv;
        } else {
            return GET_EXCEPTION;
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  uuid
 *
 *  @return
 */
+ (NSString *)jy_cfuuid
{
    @try {
        NSString *cfuuidStr = [[NAFDeviceStorage sharedInstance] getCFUUID];
        if (cfuuidStr && [cfuuidStr length]) {
            return cfuuidStr;
        } else {
            CFUUIDRef cfuuid = CFUUIDCreate(kCFAllocatorDefault);
            cfuuidStr = (NSString*)CFBridgingRelease(CFUUIDCreateString(kCFAllocatorDefault, cfuuid));
            BOOL result = [[NAFDeviceStorage sharedInstance] saveCFUUID:cfuuidStr];
            if (result) {
                return cfuuidStr;
            } else {
                return GET_EXCEPTION;
            }
        }
        return cfuuidStr;
    } @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  机型（固件版本）
 *
 *  @return iPhone 5s(GSM+CDMA)
*/

+ (NSString *)_jy_deviceType
{
    @try {
        static dispatch_once_t one;
        static NSString *deviceType;
        dispatch_once(&one, ^{
            struct utsname DT;
            uname(&DT);
            deviceType = [NSString stringWithFormat:@"%s", DT.machine];
        });
        return deviceType;
    } @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

+ (NSString *)jy_model
{
    NSString *DeviceType;
    @try {
        NSString *NewDeviceType;
        DeviceType = [self _jy_deviceType];
        if ([DeviceType isEqualToString:@"i386"])
            NewDeviceType = @"iPhone Simulator";
        else if ([DeviceType isEqualToString:@"x86_64"])
            NewDeviceType = @"iPhone Simulator";
        else if ([DeviceType isEqualToString:@"iPhone1,1"])
            NewDeviceType = @"iPhone";
        else if ([DeviceType isEqualToString:@"iPhone1,2"])
            NewDeviceType = @"iPhone 3G";
        else if ([DeviceType isEqualToString:@"iPhone2,1"])
            NewDeviceType = @"iPhone 3GS";
        else if ([DeviceType isEqualToString:@"iPhone3,1"])
            NewDeviceType = @"iPhone 4";
        else if ([DeviceType isEqualToString:@"iPhone4,1"])
            NewDeviceType = @"iPhone 4S";
        else if ([DeviceType isEqualToString:@"iPhone5,1"])
            NewDeviceType = @"iPhone 5(GSM)";
        else if ([DeviceType isEqualToString:@"iPhone5,2"])
            NewDeviceType = @"iPhone 5(GSM+CDMA)";
        else if ([DeviceType isEqualToString:@"iPhone5,3"])
            NewDeviceType = @"iPhone 5c(GSM)";
        else if ([DeviceType isEqualToString:@"iPhone5,4"])
            NewDeviceType = @"iPhone 5c(GSM+CDMA)";
        else if ([DeviceType isEqualToString:@"iPhone6,1"])
            NewDeviceType = @"iPhone 5s(GSM)";
        else if ([DeviceType isEqualToString:@"iPhone6,2"])
            NewDeviceType = @"iPhone 5s(GSM+CDMA)";
        else if ([DeviceType isEqualToString:@"iPhone7,1"])
            NewDeviceType = @"iPhone 6 Plus";
        else if ([DeviceType isEqualToString:@"iPhone7,2"])
            NewDeviceType = @"iPhone 6";
        else if ([DeviceType isEqualToString:@"iPhone8,1"])
            NewDeviceType = @"iPhone 6s";
        else if ([DeviceType isEqualToString:@"iPhone8,2"])
            NewDeviceType = @"iPhone 6s Plus";
        else if ([DeviceType isEqualToString:@"iPhone8,4"])
            NewDeviceType = @"iPhone SE";
        else if ([DeviceType isEqualToString:@"iPod1,1"])
            NewDeviceType = @"iPod Touch 1G";
        else if ([DeviceType isEqualToString:@"iPod2,1"])
            NewDeviceType = @"iPod Touch 2G";
        else if ([DeviceType isEqualToString:@"iPod3,1"])
            NewDeviceType = @"iPod Touch 3G";
        else if ([DeviceType isEqualToString:@"iPod4,1"])
            NewDeviceType = @"iPod Touch 4G";
        else if ([DeviceType isEqualToString:@"iPod5,1"])
            NewDeviceType = @"iPod Touch 5G";
        else if ([DeviceType isEqualToString:@"iPod7,1"])
            NewDeviceType = @"iPod Touch 6G";
        else if ([DeviceType isEqualToString:@"iPad1,1"])
            NewDeviceType = @"iPad";
        else if ([DeviceType isEqualToString:@"iPad2,1"])
            NewDeviceType = @"iPad 2(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad2,2"])
            NewDeviceType = @"iPad 2(GSM)";
        else if ([DeviceType isEqualToString:@"iPad2,3"])
            NewDeviceType = @"iPad 2(CDMA)";
        else if ([DeviceType isEqualToString:@"iPad2,4"])
            NewDeviceType = @"iPad 2(WiFi + New Chip)";
        else if ([DeviceType isEqualToString:@"iPad2,5"])
            NewDeviceType = @"iPad mini(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad2,6"])
            NewDeviceType = @"iPad mini(GSM)";
        else if ([DeviceType isEqualToString:@"iPad2,7"])
            NewDeviceType = @"iPad mini(GSM+CDMA)";
        else if ([DeviceType isEqualToString:@"iPad3,1"])
            NewDeviceType = @"iPad 3(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad3,2"])
            NewDeviceType = @"iPad 3(GSM+CDMA)";
        else if ([DeviceType isEqualToString:@"iPad3,3"])
            NewDeviceType = @"iPad 3(GSM)";
        else if ([DeviceType isEqualToString:@"iPad3,4"])
            NewDeviceType = @"iPad 4(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad3,5"])
            NewDeviceType = @"iPad 4(GSM)";
        else if ([DeviceType isEqualToString:@"iPad3,6"])
            NewDeviceType = @"iPad 4(GSM+CDMA)";
        else if ([DeviceType isEqualToString:@"iPad3,3"])
            NewDeviceType = @"New iPad";
        else if ([DeviceType isEqualToString:@"iPad4,1"])
            NewDeviceType = @"iPad Air(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad4,2"])
            NewDeviceType = @"iPad Air(Cellular)";
        else if ([DeviceType isEqualToString:@"iPad4,4"])
            NewDeviceType = @"iPad mini 2(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad4,5"])
            NewDeviceType = @"iPad mini 2(Cellular)";
        else if ([DeviceType isEqualToString:@"iPad5,1"])
            NewDeviceType = @"iPad mini 4(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad5,2"])
            NewDeviceType = @"iPad mini 4(Cellular)";
        else if ([DeviceType isEqualToString:@"iPad5,4"])
            NewDeviceType = @"iPad Air 2(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad5,5"])
            NewDeviceType = @"iPad Air 2(Cellular)";
        else if ([DeviceType isEqualToString:@"iPad6,3"])
            NewDeviceType = @"9.7-inch iPad Pro(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad6,4"])
            NewDeviceType = @"9.7-inch iPad Pro(Cellular)";
        else if ([DeviceType isEqualToString:@"iPad6,7"])
            NewDeviceType = @"12.9-inch iPad Pro(WiFi)";
        else if ([DeviceType isEqualToString:@"iPad6,8"])
            NewDeviceType = @"12.9-inch iPad Pro(Cellular)";
        else if ([DeviceType hasPrefix:@"iPad"])
            NewDeviceType = @"iPad";
        return [NSString stringWithFormat:@"%@[%@]",DeviceType,NewDeviceType];
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  总空间(不含拓展卡）
 *
 *  @return 2.57 GB
 */
+ (NSString *)jy_totalStorage
{
    @try {
        long long Space = [self _jy_longDiskSpace];
        if (Space <= 0) {
            return GET_EXCEPTION;
        }
        NSString *DiskSpace = [self _jy_formatMemory:Space];
        
        if (DiskSpace == nil || DiskSpace.length <= 0) {
            return GET_EXCEPTION;
        }
        return DiskSpace;
    }
    @catch (NSException * ex) {
        return GET_EXCEPTION;
    }
    
}

+ (long long)_jy_longDiskSpace {
    @try {
        long long DiskSpace = 0L;
        NSError *Error = nil;
        NSDictionary *FileAttributes = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:&Error];
        
        if (Error == nil) {
            DiskSpace = [[FileAttributes objectForKey:NSFileSystemSize] longLongValue];
        } else {
            return -1;
        }
        if (DiskSpace <= 0) {
            return -1;
        }
        return DiskSpace;
    }
    @catch (NSException *exception) {
        return -1;
    }
}

//可以写到外面
+ (NSString *)_jy_formatMemory:(long long)Space {
    @try {
        NSString *FormattedBytes = nil;
        double NumberBytes = 1.0 * Space;
        double TotalGB = NumberBytes / (1024*1024*1024);
        FormattedBytes = [NSString stringWithFormat:@"%.2f GB", TotalGB];
        if (FormattedBytes == nil || FormattedBytes.length <= 0) {
            return nil;
        }
        return FormattedBytes;
    }
    @catch (NSException *exception) {
        return nil;
    }
}

/**
 *  IP
 *
 *  @return
 */
+ (NSString *)jy_cellIPAddress
{
    @try {
        NSString *IPAddress;
        struct ifaddrs *Interfaces;
        struct ifaddrs *Temp;
        struct sockaddr_in *s4;
        char buf[64];
        
        if (!getifaddrs(&Interfaces))
        {
            Temp = Interfaces;
            while(Temp != NULL)
            {
                //TODO
                if(Temp->ifa_addr->sa_family == AF_INET)
                {
                    if([[NSString stringWithUTF8String:Temp->ifa_name] isEqualToString:@"pdp_ip0"])
                    {
                        s4 = (struct sockaddr_in *)Temp->ifa_addr;
                        
                        if (inet_ntop(Temp->ifa_addr->sa_family, (void *)&(s4->sin_addr), buf, sizeof(buf)) == NULL) {
                            IPAddress = nil;
                        } else {
                            IPAddress = [NSString stringWithUTF8String:buf];
                        }
                    }
                }
                Temp = Temp->ifa_next;
            }
        }
        freeifaddrs(Interfaces);
        if (IPAddress == nil || IPAddress.length <= 0) {
            return GET_EXCEPTION;
        }
        return IPAddress;
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

+ (NSString *)agentIP
{
    CFDictionaryRef proxySettings = CFNetworkCopySystemProxySettings();
    NSDictionary *dictProxy = (__bridge_transfer id)proxySettings;
    //是否开启了http代理
    NSString *httpAgentIP = @"";
    if ([[dictProxy objectForKey:@"HTTPEnable"] boolValue]) {
        NSString *proxyAddress = [dictProxy objectForKey:@"HTTPProxy"]; //代理地址
        NSInteger proxyPort = [[dictProxy objectForKey:@"HTTPPort"] integerValue];  //代理端口号
        httpAgentIP = [NSString stringWithFormat:@"%@:%ld",proxyAddress,(long)proxyPort];
    }
    return httpAgentIP;
}

//+(NSString *)bluetoothMAC
//{
//    CBUUID *macServiceUUID = [CBUUID UUIDWithString:@"180A"];
//    CBUUID *macCharcteristicUUID = [CBUUID UUIDWithString:@"2A23"];
//    NSString *value = [NSString stringWithFormat:@"%@",characteristic.value];
//    NSMutableString *macString = [[NSMutableString alloc] init];
//    [macString appendString:[[value substringWithRange:NSMakeRange(16, 2)] uppercaseString]];
//    [macString appendString:@":"];
//    [macString appendString:[[value substringWithRange:NSMakeRange(14, 2)] uppercaseString]];
//    [macString appendString:@":"];
//    [macString appendString:[[value substringWithRange:NSMakeRange(12, 2)] uppercaseString]];
//    [macString appendString:@":"];
//    [macString appendString:[[value substringWithRange:NSMakeRange(5, 2)] uppercaseString]];
//    [macString appendString:@":"];
//    [macString appendString:[[value substringWithRange:NSMakeRange(3, 2)] uppercaseString]];
//    [macString appendString:@":"];
//    [macString appendString:[[value substringWithRange:NSMakeRange(1, 2)] uppercaseString]];
//    NSLog(@"macString:%@",macString);
//}
/**
 *
 *
 *  @return 02:00:00:00:00:00
 */
+ (NSString *)jy_cellMacAddress
{
    @try {
        int                 mgmtInfoBase[6];
        char                *msgBuffer = NULL;
        size_t              length;
        unsigned char       macAddress[6];
        struct if_msghdr    *interfaceMsgStruct;
        struct sockaddr_dl  *socketStruct;
        
        mgmtInfoBase[0] = CTL_NET;        // Request network subsystem
        mgmtInfoBase[1] = AF_ROUTE;       // Routing table info
        mgmtInfoBase[2] = 0;
        mgmtInfoBase[3] = AF_LINK;        // Request link layer information
        mgmtInfoBase[4] = NET_RT_IFLIST;  // Request all configured interfaces
        
        if ((mgmtInfoBase[5] = if_nametoindex([@"pdp_ip0" UTF8String])) == 0) {
            return GET_EXCEPTION;
        } else {
            if (sysctl(mgmtInfoBase, 6, NULL, &length, NULL, 0) < 0)
                return GET_EXCEPTION;
            else
            {
                if ((msgBuffer = malloc(length)) == NULL)
                    return GET_EXCEPTION;
                else
                {
                    if (sysctl(mgmtInfoBase, 6, msgBuffer, &length, NULL, 0) < 0)
                        return GET_EXCEPTION;
                }
            }
        }
        interfaceMsgStruct = (struct if_msghdr *) msgBuffer;
        socketStruct = (struct sockaddr_dl *) (interfaceMsgStruct + 1);
        memcpy(&macAddress, socketStruct->sdl_data + socketStruct->sdl_nlen, 6);
        
        NSString *macAddressString = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",
                                      macAddress[0], macAddress[1], macAddress[2],
                                      macAddress[3], macAddress[4], macAddress[5]];
        free(msgBuffer);
        NSString *deviceID = macAddressString;
        if (NAF_CHECK_VALID_STRING(deviceID)) {
            return deviceID;
        } else {
            return GET_EXCEPTION;
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  模拟器
 *
 *  @return 1/0
 */
+ (NSString *)jy_isSimulator
{
    @try {
        NSString * deviceType = [self _jy_deviceType];
        if ([deviceType isEqualToString:@"i386"] || [deviceType isEqualToString:@"x86_64"]) {
            return @"1";
        } else {
            return @"0";
        }
    } @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  运营商
 *
 *  @return 中国联通
 */
+ (NSString *)jy_carrier
{
    @try {
        CTTelephonyNetworkInfo *TelephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
        CTCarrier *Carrier = [TelephonyInfo subscriberCellularProvider];
        NSString *carrier = [Carrier carrierName];
        if (NAF_CHECK_VALID_STRING(carrier)) {
            return carrier;
        } else {
            return GET_EXCEPTION;
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  当前网络类型
 *
 *  2G 3G 4G WiFi NotReachable NA
 */
+ (NSString *)jy_networkType
{
    @try {
        if (![[NAFNetworkReachabilityManager sharedManager] isReachable]) {
            return @"NotReachable";
        }
        
        if ([[NAFNetworkReachabilityManager sharedManager] isReachableViaWiFi]) {
            return @"WiFi";
        }
        CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
        NSString *currentStatus  = [telephonyInfo currentRadioAccessTechnology];
        
        if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyLTE"]) {
            return @"4G";
        }
        if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyWCDMA"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyHSDPA"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyHSUPA"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORev0"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevA"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevB"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyeHRPD"]) {
            return @"3G";
        }
        if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyGPRS"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyEdge"] ||
            [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMA1x"]) {
            return @"2G";
        }
        return GET_EXCEPTION;
    } @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *
 *
 *  @return CN
 */
+ (NSString *)jy_country
{
    @try {
        CTTelephonyNetworkInfo *TelephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
        CTCarrier *Carrier = [TelephonyInfo subscriberCellularProvider];
        NSString *country = [Carrier isoCountryCode];
        if (NAF_CHECK_VALID_STRING(country)) {
            return country;
        } else {
            return GET_EXCEPTION;
        }
    }
    @catch (NSException *exception) {
        return GET_EXCEPTION;
    }
}

/**
 *  CPU支持的指令集
 *
 *  @return arm64
 */
+ (NSString *)jy_cpuABI
{
    const NXArchInfo *archInfo = NXGetLocalArchInfo();
    NSString *cpuABIStr = [NSString stringWithUTF8String:archInfo->name];
    if (NAF_CHECK_VALID_STRING(cpuABIStr)) {
        return cpuABIStr;
    } else {
        return GET_EXCEPTION;
    }
}

/**
 *  CPU 主频
 *
 *  @return
 */
+ (NSString *)jy_cpuSpeed
{
    unsigned int result;
    int mib[2];
    mib[0] = CTL_HW;
    mib[1] = HW_CPU_FREQ;
    size_t length = sizeof(result);
    if (sysctl(mib, 2, &result, &length, NULL, 0) < 0)
    {
        return GET_EXCEPTION;
    }
    return [NSString stringWithFormat:@"%u hz",result];

}

+ (NSString *)getCurrentLanguage
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    return currentLanguage;
}

@end


@implementation UIApplication (NAFAdd)

- (NSString *)appVersion
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
}

- (NSString *)appBundleId
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleIdentifier"];
}

@end

@implementation UIScreen (NAFAdd)

- (CGSize)sizeInPixel
{
    static dispatch_once_t one;
    static CGSize size;
    
    dispatch_once(&one, ^{
        size = CGSizeZero;
        if ([[UIScreen mainScreen] isEqual:self]) {
            NSString *model = [UIDevice currentDevice].machineModel;
            if ([model hasPrefix:@"iPhone"]) {
                if ([model hasPrefix:@"iPhone1"]) size = CGSizeMake(320, 480);
                else if ([model hasPrefix:@"iPhone2"]) size = CGSizeMake(320, 480);
                else if ([model hasPrefix:@"iPhone3"]) size = CGSizeMake(640, 960);
                else if ([model hasPrefix:@"iPhone4"]) size = CGSizeMake(640, 960);
                else if ([model hasPrefix:@"iPhone5"]) size = CGSizeMake(640, 1136);
                else if ([model hasPrefix:@"iPhone6"]) size = CGSizeMake(640, 1136);
                else if ([model hasPrefix:@"iPhone7,1"]) size = CGSizeMake(1080, 1920);
                else if ([model hasPrefix:@"iPhone7,2"]) size = CGSizeMake(750, 1334);
                else if ([model hasPrefix:@"iPhone8,1"]) size = CGSizeMake(1080, 1920);
                else if ([model hasPrefix:@"iPhone8,2"]) size = CGSizeMake(750, 1334);
                else if ([model hasPrefix:@"iPhone8,4"]) size = CGSizeMake(640, 1136);
            } else if ([model hasPrefix:@"iPod"]) {
                if ([model hasPrefix:@"iPod1"]) size = CGSizeMake(320, 480);
                else if ([model hasPrefix:@"iPod2"]) size = CGSizeMake(320, 480);
                else if ([model hasPrefix:@"iPod3"]) size = CGSizeMake(320, 480);
                else if ([model hasPrefix:@"iPod4"]) size = CGSizeMake(640, 960);
                else if ([model hasPrefix:@"iPod5"]) size = CGSizeMake(640, 1136);
                else if ([model hasPrefix:@"iPod7"]) size = CGSizeMake(640, 1136);
            } else if ([model hasPrefix:@"iPad"]) {
                if ([model hasPrefix:@"iPad1"]) size = CGSizeMake(768, 1024);
                else if ([model hasPrefix:@"iPad2"]) size = CGSizeMake(768, 1024);
                else if ([model hasPrefix:@"iPad3"]) size = CGSizeMake(1536, 2048);
                else if ([model hasPrefix:@"iPad4"]) size = CGSizeMake(1536, 2048);
                else if ([model hasPrefix:@"iPad5"]) size = CGSizeMake(1536, 2048);
                else if ([model hasPrefix:@"iPad6,3"]) size = CGSizeMake(1536, 2048);
                else if ([model hasPrefix:@"iPad6,4"]) size = CGSizeMake(1536, 2048);
                else if ([model hasPrefix:@"iPad6,7"]) size = CGSizeMake(2048, 2732);
                else if ([model hasPrefix:@"iPad6,8"]) size = CGSizeMake(2048, 2732);
            }
        }
        
        if (CGSizeEqualToSize(size, CGSizeZero)) {
            if ([self respondsToSelector:@selector(nativeBounds)]) {
                size = self.nativeBounds.size;
            } else {
                size = self.bounds.size;
                size.width *= self.scale;
                size.height *= self.scale;
            }
            if (size.height < size.width) {
                CGFloat tmp = size.height;
                size.height = size.width;
                size.width = tmp;
            }
        }
        
    });
    
    return size;
}

@end

@implementation NAFTelephoneUtils

+ (NSString *)carrierName
{
    static dispatch_once_t one;
    static NSString *carrierName;
    
    dispatch_once(&one, ^{
        CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
        CTCarrier *carrier = [telephonyInfo subscriberCellularProvider];
        carrierName = [carrier carrierName];
        
        if (nil == carrierName) {
            carrierName = @"";
        }
    });
    
    return carrierName;
}

+ (NSString *)netWorkType
{
    if (![[NAFNetworkReachabilityManager sharedManager] isReachable]) {
        return @"NotReachable";
    }
    
    if ([[NAFNetworkReachabilityManager sharedManager] isReachableViaWiFi]) {
        return @"WiFi";
    }
    
    if (NAF_IS_OS_6_OR_EARLIER) {
        return @"Unknown";
    }
    
    CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
    NSString *currentStatus  = [telephonyInfo currentRadioAccessTechnology];
    
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyLTE"]) {
        return @"4G";
    }
    
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyWCDMA"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyHSDPA"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyHSUPA"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORev0"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevA"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevB"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyeHRPD"]) {
        return @"3G";
    }
    
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyGPRS"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyEdge"] ||
        [currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMA1x"]) {
        return @"2G";
    }
    
    return @"Unknown";
}

@end
//
//  JYDeviceUtils.m
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import "NAFDeviceUtils.h"
#import "UIDevice+NAFHardware.h"
#import "NAFReportDefine.h"
#import "NAFDeviceFingerAdditions.h"

@implementation NAFDeviceUtils

+ (NSDictionary *)collectDeviceInfo
{
    NSMutableDictionary *deviceInfo = [[NSMutableDictionary alloc] init];
    [deviceInfo jy_safeSetObject:[UIDevice jy_resolution] forKey:@"resolution"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_totalMemory] forKey:@"totalMemory"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_isJailBreak] forKey:@"breakFlag"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_cpuCount] forKey:@"cpuCount"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_identifierForAdvertising] forKey:@"idfa"];
    
    [deviceInfo jy_safeSetObject:[UIDevice jy_identifierForVendor] forKey:@"idfv"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_cfuuid] forKey:@"uuid"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_model] forKey:@"model"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_totalStorage] forKey:@"totalStorage"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_cellIPAddress] forKey:@"cellIp"];
    
    [deviceInfo jy_safeSetObject:[UIDevice jy_cellMacAddress] forKey:@"cellMac"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_isSimulator] forKey:@"simulator"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_carrier] forKey:@"carrier"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_networkType] forKey:@"networkType"];
    
    [deviceInfo jy_safeSetObject:[UIDevice jy_country] forKey:@"country"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_cpuABI] forKey:@"cpuABI"];
    [deviceInfo jy_safeSetObject:[UIDevice jy_cpuSpeed] forKey:@"cpuSpeed"];


    
    return deviceInfo;
}
@end

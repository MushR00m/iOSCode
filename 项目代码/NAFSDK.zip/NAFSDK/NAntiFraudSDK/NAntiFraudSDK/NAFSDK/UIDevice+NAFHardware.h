//
//  UIDevice+JYHardware.h
//  JYDeviceFingerSDK
//
//  Created by chensongqi on 16/8/1.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (NAFHardware)

+ (NSString *)systemName;
+ (NSString *)systemVersion;
+ (NSString *)phoneNumber;
/**
 *  运营商
 *
 *  @return 中国联通
 */
+ (NSString *)carrier;

- (NSString *)machineModel;
- (NSString *)machineModelName;

+ (NSString *) macString;
+ (NSString *) idfaString;
+ (NSString *)uuid;
/**
 *  屏幕分辨率
 *
 *  @return 375x667
 */
+ (NSString *)jy_resolution;

/**
 *  系统总存
 *
 *  @return 1015.66 MB
 */
+ (NSString *)jy_totalMemory;

/**
 *  越狱标识
 *
 *  @return YES/NO
 */
+ (NSString *)jy_isJailBreak;

/**
 *   cpu数量
 *
 *  @return 2
 */
+ (NSString *)jy_cpuCount;

/**
 *  idfa
 *
 *  @return 7E0535C8-4BAA-481C-AC35-EC5662DBBE02
 */
+ (NSString *)jy_identifierForAdvertising;

/**
 *  idfv
 *
 *  @return B14E3003-9639-49AB-B4A3-F047C7FC9020"
 */
+ (NSString *)jy_identifierForVendor;

/**
 *  uuid
 *
 *  @return
 */
+ (NSString *)jy_cfuuid;

/**
 *  机型（固件版本）
 *
 *  @return iPhone 5s(GSM+CDMA)
 */
+ (NSString *)jy_model;

/**
 *  总空间(不含拓展卡）
 *
 *  @return 2.57 GB
 */
+ (NSString *)jy_totalStorage;

/**
 *  IP
 *
 *  @return
 */
+ (NSString *)jy_cellIPAddress;

//代理IP
+ (NSString *)agentIP;

/**
 *
 *
 *  @return 02:00:00:00:00:00
 */
+ (NSString *)jy_cellMacAddress;

/**
 *  模拟器
 *
 *  @return YES/NO
 */
+ (NSString *)jy_isSimulator;

/**
 *  运营商
 *
 *  @return 中国联通
 */
+ (NSString *)jy_carrier;

/**
 *  当前网络类型
 *
 *  @return WiFi/4G/3G/2G
 */
+ (NSString *)jy_networkType;

/**
 *
 *
 *  @return CN
 */
+ (NSString *)jy_country;


/**
 *  CPU支持的指令集
 *
 *  @return arm64
 */
+ (NSString *)jy_cpuABI;

/**
 *  CPU 主频
 *
 *  @return
 */
+ (NSString *)jy_cpuSpeed;

+ (NSString *)getCurrentLanguage;

@end

@interface UIApplication (NAFAdd)

- (NSString *)appVersion;
- (NSString *)appBundleId;

@end


@interface UIScreen (NAFAdd)

- (CGSize)sizeInPixel;

@end

#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>

@interface NAFTelephoneUtils : NSObject

+ (NSString *)carrierName;
+ (NSString *)netWorkType;

@end


//
//  NWDAFReport.h
//  JYDeviceManager
//
//  Created by yangmengge on 16/8/30.
//  Copyright © 2016年 chensongqi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NAFReportDefine.h"

@interface NAFReportUtils : NSObject

+ (NSString *)version;

//启动APP
+ (void)initWithAPPKey:(NSString *)key;
+ (void)initWithAPPKey:(NSString *)key data:(NSDictionary *)data;

+ (void)trackWithName:(NSString *)name;
//老代码
+ (void)trackWithName:(NSString *)name data:(NSDictionary *)data;

@end

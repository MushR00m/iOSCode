//
//  NAntiFraudSDK.h
//  NAntiFraudSDK
//
//  Created by yangmengge on 16/8/30.
//  Copyright © 2016年 niwodai. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NAntiFraudSDK.
FOUNDATION_EXPORT double NAntiFraudSDKVersionNumber;

//! Project version string for NAntiFraudSDK.
FOUNDATION_EXPORT const unsigned char NAntiFraudSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NAntiFraudSDK/PublicHeader.h>


